using Distributed 
addprocs(1)



@everywhere using ProgressMeter
@everywhere function execute(task)
    loss_type, i = task
    cmd = `python example1_base_speed_evaluation.py --loss=$(loss_type) --repeat=$(i)`
    # use pipe to capture the stdout and stderr to log/
    run(pipeline(
        cmd, 
        stdout="log/example1_$(loss_type)_$(repeat).out", 
        stderr="log/example1_$(loss_type)_$(repeat).err"))
end
tasks = [
    (loss_type, i) for loss_type in [
            "mse", 
            "mmd", 
            "mean2_var", 
            "w2_decoupled", 
            "w2_coupled",
            "w1_coupled"
            ],
    i ∈ 0:0
]

progress_pmap(
    execute, tasks;
    progress = Progress(length(tasks), showspeed=true)
)