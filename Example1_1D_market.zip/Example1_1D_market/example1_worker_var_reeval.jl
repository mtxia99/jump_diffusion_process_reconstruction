using Distributed 
addprocs(5)


@everywhere using ProgressMeter
@everywhere function execute(task)
    loss_type, i, sigma_para, sigma_para2 = task
    cmd = `python example1_eval_var.py --loss=$(loss_type) --repeat=$(i) --sigma_para=$(sigma_para) --sigma_para2=$(sigma_para2)`
    # use pipe to capture the stdout and stderr to log/
    run(pipeline(
        cmd, 
        stdout="log/example1_reeval_$(loss_type)_$(repeat)_$(sigma_para)_$(sigma_para2).out", 
        stderr="log/example1_reeval_$(loss_type)_$(repeat)_$(sigma_para)_$(sigma_para2).err"))
end
tasks = [
    (loss_type, i, σ1, σ2) for loss_type in ["w2_decoupled"],
    i ∈ 0:1, σ1 ∈ 0.2:0.04:0.4, σ2 ∈ 0.5:0.1:1.0
]

progress_pmap(
    execute, tasks;
    progress = Progress(length(tasks), showspeed=true)
)