using Distributed 
addprocs(2)

cmds = [
    `python example1_wgan.py --loss=$(loss_type) --repeat=$(i)`
    for loss_type in ["wgan"],
        i ∈ 0:9
]

@everywhere using ProgressMeter
@everywhere function execute(task)
    loss_type, i = task
    cmd = `python example1_wgan.py --loss=$(loss_type) --repeat=$(i)`
    # use pipe to capture the stdout and stderr to log/
    run(pipeline(
        cmd, 
        stdout="log/example1_$(loss_type)_$(repeat).out", 
        stderr="log/example1_$(loss_type)_$(repeat).err"))
end
tasks = [
    (loss_type, i) for loss_type in ["wgan"],
    i ∈ 0:9
]

progress_pmap(
    execute, tasks;
    progress = Progress(length(tasks), showspeed=true)
)