# Example 1
## Dependency
The modified package of `torchsde` is located in `torchsde_master_homogeneous`.

Credit: Mingtao Xia

## Python scripts
- `example1_base.py` The main file for training the neural network and report loss.
- `example1_base_var.py` Experiments with different noise levels.
- `example1_base_y0_noise.py` Experiments with different initial distributions
- `example1_wgan.py` WGAN implementation.

Credit: Mingtao Xia

## Julia scripts
Training task scheduling:
- `example1_worker.jl` Worker script for training the neural network (main text).
- `example1_worker_var.jl` Worker script for training the neural network with different noise levels.
- `example1_worker_y0_noise.jl` Worker script for training the neural network with different initial distributions.
- `example1_worker_wgan.jl` Worker script for training the neural network with WGAN.

For plotting and analysis purposes. In terms of plotting, requires PGFPlotsX and external LaTeX installation that includes PGFPlots.
- `example1_plot.jl` Plotting the sample trajectories.
- `example1_analysis.jl` Loss and error plotting.
- `example1_analysis_var.jl` Loss and error plotting with different noise levels.
- `example1_analysis_y0_noise.jl` Loss and error plotting with different initial distributions.

