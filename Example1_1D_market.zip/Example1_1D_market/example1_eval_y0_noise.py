
import torch

torch.set_num_threads(1)
from torchsde_master_homogeneous import *
from torchsde_master_homogeneous.torchsde._core.sdeint import *
import pandas as pd
import random
import time
import csv
from tqdm import tqdm
from math import sqrt
import pdb
import sys
sys.setrecursionlimit(5000)
device = torch.device("cpu" if torch.cuda.is_available() else "cpu")
import psutil
import os
import argparse

#### Options ####
# first check if running in ipython kernel (jupyter notebook)
# if so, use default arguments

if 'ipykernel' in sys.modules:
    noise_type = 'langevin'
    loss_type = 'mmd'
    repeat = 0
    ini_noise_std = 0.1
    print('running in jupyter notebook')

else:
    # otherwise, parse arguments from command line
    parser = argparse.ArgumentParser(description='jump SDE')
    parser.add_argument('--noise_type', default='langevin', type=str, help='type of noise',  required=False)
    parser.add_argument('--loss', default='w2_decoupled', type=str, help='type of loss', required=False)
    parser.add_argument('--repeat', default=0, type=int, help='repeat number', required=False)
    parser.add_argument('--ini_noise_std', default=0.1, type=float, help='initial noise variance', required=False)
    # parse arguments
    args = parser.parse_args()
    noise_type = args.noise_type
    loss_type = args.loss
    repeat = args.repeat
    ini_noise_std = args.ini_noise_std
# print parsed arguments
print('noise_type: ', noise_type)
print('loss_type: ', loss_type)
print('repeat: ', repeat)
# exit(1)
sigma_para = 0.4
sigma_para2 = 1.0
cor = 0 
### Monitor memory usage ###
# Get the process ID
pid = os.getpid()
# Get the process object using the process ID
process = psutil.Process(pid)

############################
#### Check if the results have been generated ####
results = [    "data/example1_ground_truth" + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + str(noise_type) + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/example1_prediction" + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/example1_loss2d"+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/example1_f_error"+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/example1_s_error"+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/example1_h_error"+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv',
    "data/model" + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + str(loss_type) + str(ini_noise_std) + '.pkl',
]
run_flag = False
for result in results:
    print(result)
    print(os.path.exists(result))
    if not os.path.exists(result):
        run_flag = True
        break
if not run_flag:
    print('results already exist')
    exit()

############################
batch_size, state_size, brownian_size, levy_size = 100, 1, 1, 1
H = 150
t_size = 101
class TwoLayerNet(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        """
        In the constructor we instantiate two nn.Linear modules and assign them as
        member variables.
        """
        super(TwoLayerNet, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H)
        self.linear2 = torch.nn.Linear(H, H)
        self.linear3 = torch.nn.Linear(H, D_out)
        
        #return data
    
    def forward(self, x):
        """
        In the forward function we accept a Tensor of input data and we must return
        a Tensor of output data. We can use Modules defined in the constructor as
        well as arbitrary operators on Tensors.
        """
        h_relu1 = self.linear1(x)
        h_relu1 = torch.relu(h_relu1)
        h_relu2 = self.linear2(h_relu1)
        h_relu2 = torch.relu(h_relu2)
        y_pred = self.linear3(h_relu2)
        return y_pred

params = [1, 0.21]

### Define the SDEs...
class SDE(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'

    def __init__(self):
        super().__init__()
        self.mu = TwoLayerNet(state_size, H, state_size)
        self.sigma = TwoLayerNet(state_size, H, state_size * brownian_size)
        self.jump = TwoLayerNet(state_size, H, state_size * levy_size)

    # Drift
    def f(self, t, y):
        t = t.expand(y.size(0), 1)
        ty = torch.cat([t, y], dim=1).to(device)
        return self.mu(y)  # shape (batch_size, state_size)

    # Diffusion
    def g(self, t, y):
        t = t.expand(y.size(0), 1)
        ty = torch.cat([t, y], dim=1).to(device)
        sigma_matrix = self.sigma(y).view(batch_size, state_size, brownian_size)
        return sigma_matrix
    
    def h(self, t, y):
        jump_matrix = self.jump(y).view(batch_size, state_size, levy_size)
        return jump_matrix

class SDE_truth(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'
    
    def __init__(self):
        super().__init__()


    # Drift
    def f(self, t, y):
        #print(y.shape)
        f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
        for i in range(y.shape[0]):
            f_truth[i, 0] = 5 - params[0]*y[i, 0]
            
        return f_truth  # shape (batch_size, state_size)

    # Diffusion
    def g(self, t, y):
        global noise_type
        g_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
        for i in range(y.shape[0]):
            if noise_type == 'const':
                g_truth[i, 0, 0] = sigma_para 
            elif noise_type == 'linear':
                g_truth[i, 0, 0] = sigma_para * y[i, 0] 
            elif noise_type == 'langevin':
                g_truth[i, 0, 0] = sigma_para * sqrt(abs(y[i, 0])) 
            
            
        return g_truth #* sigma_para
    
    def h(self, t, y):
        global noise_type
        h_truth = torch.zeros(y.shape[0], y.shape[1], levy_size).to(device)
        for i in range(y.shape[0]):
            if noise_type == 'const':
                h_truth[i, 0, 0] = sigma_para2 
            elif noise_type == 'linear':
                h_truth[i, 0, 0] = sigma_para2 * y[i, 0] 
            elif noise_type == 'langevin':
                h_truth[i, 0, 0] = sigma_para2 
            
            
        return h_truth
    
b = 5
sigma = 0.4
v = 0.1
from math import sqrt
print('initialized')
#
# for each sigma = 0.02:0.02:0.18, each cor=-1:-.25:1
# for each noise type const, linear, langevin
# repeat 10 experiments, a total of 810 models 

a = 0.1 -  sigma_para**2 / 2 * (1+1/4)
if cor == 0:
    x = 1
else:
    x = (2 - sqrt(4 - 4 * cor**2)) / 2 / cor
    
Sigma = [[0.1, -0.05], [-0.05, 0.05]]

from math import pi    
import ot    
import gc
### Define the distance functions...
def distance(P, Q):
    cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
    return cost_matrix

def w2_decoupled(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    for i in range(1, t_size):
        weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)

        loss += ot.emd2(weights, weights, distance(y[i, :, :], y_pred[i, :, :]))
    
    return loss

def w2_coupled(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    y_coupled = torch.zeros(batch_size, state_size * t_size)
    y_pred_coupled = torch.zeros(batch_size, state_size * t_size)
    for i in range(0, t_size):
        y_coupled[:, i*state_size:(i+1)*state_size] += y[i, :, :]
        y_pred_coupled[:, i*state_size:(i+1)*state_size] += y_pred[i, :, :]
    
    weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)

    loss += ot.emd2(weights, weights, distance(y_coupled[:, :], y_pred_coupled[:, :]))
    
    return loss

def mean2_var_distance(u_samples, v_samples):
    # regard the samples as a tensor, the first index is the sample index
    # rest of them compose a sub-tensor
    # first average over the sample index, then compute the mean and variance
    # of the sub-tensor
    u_mean = torch.mean(u_samples, dim=0)
    u_var = torch.var(u_samples, dim=0)
    v_mean = torch.mean(v_samples, dim=0)
    v_var = torch.var(v_samples, dim=0)
    return torch.norm(u_mean - v_mean)**2 + torch.norm(u_var - v_var)**2

def mse_distance(u_samples, v_samples):
    return torch.mean((u_samples - v_samples)**2)

class RBF(torch.nn.Module): 
    def __init__(self, n_kernels=5, mul_factor=2.0, bandwidth=None):
        super().__init__()
        self.bandwidth_multipliers = mul_factor ** (torch.arange(n_kernels) - n_kernels // 2)
        self.bandwidth = bandwidth

    def get_bandwidth(self, L2_distances):
        if self.bandwidth is None:
            n_samples = L2_distances.shape[0]
            return L2_distances.data.sum() / (n_samples ** 2 - n_samples)

        return self.bandwidth

    def forward(self, X):
        L2_distances = torch.cdist(X, X) ** 2
        return torch.exp(-L2_distances[None, ...] / (self.get_bandwidth(L2_distances) * self.bandwidth_multipliers)[:, None, None]).sum(dim=0)

# Maximum Mean Discrepancy loss
# Ref: https://github.com/yiftachbeer/mmd_loss_pytorch
# Ref: https://arxiv.org/abs/1502.02761
class MMDLoss(torch.nn.Module):
    def __init__(self, kernel=RBF()):
        super().__init__()
        self.kernel = kernel

    def forward(self, X, Y):
        K = self.kernel(torch.vstack([X, Y]))
        X_size = X.shape[0]
        XX = K[:X_size, :X_size].mean()
        XY = K[:X_size, X_size:].mean()
        YY = K[X_size:, X_size:].mean()
        return XX - 2 * XY + YY

mmd_distance = MMDLoss()

#### Define loss function based on argument ####
if loss_type == 'w2_decoupled':
    loss_func = w2_decoupled
elif loss_type == 'w2_coupled':
    loss_func = w2_coupled
elif loss_type == 'mean2_var':
    def loss_func(y, y_pred):
        # get t size (first dimension of y)
        t_size = y.shape[0]
        loss = 0
        for i in range(t_size):
            loss += mean2_var_distance(y[i, :, :], y_pred[i, :, :])
        return loss
elif loss_type == 'mse':
    loss_func = mse_distance
elif loss_type == 'mmd':
    def loss_func(y, y_pred):
        # get t size (first dimension of y)
        t_size = y.shape[0]
        loss = 0
        for i in range(t_size):
            if i == 0:
                continue
            loss += mmd_distance(y[i, :, :], y_pred[i, :, :])
        return loss
else:
    raise ValueError('Invalid loss type')

sde = SDE().to(device)
sde_truth = SDE_truth().to(device)
y0 = (torch.ones(batch_size, state_size) * 2 + ini_noise_std * torch.randn(batch_size, state_size)).to(device)
        
t_end = 20
ts = torch.linspace(0, t_end, t_size).to(device)
with torch.no_grad():
    ys_truth = sdeint(sde_truth, y0, ts).to(device)
print('ground truth generated')
# truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
# truth_data.to_csv('data/example1_ground_truth' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(cor) + '_' + str(repeat) + '_' + str(noise_type) + '.csv', header=False, index = False)
# read saved ground truth in csv, and convert to tensor ys_truth
# truth_data = pd.read_csv('data/example1_ground_truth' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(cor) + '_' + str(repeat) + '_' + str(noise_type) + '.csv', header=None)
# ys_truth1 = torch.tensor(truth_data.values).to(device) # shape (batch_size, t_size)
# # need to be shape (batch_size, t_size, state_size=1)
# ys_truth = ys_truth1.unsqueeze(2)
# # also need to swap the first two dimensions
# ys_truth = ys_truth.permute(1, 0, 2)

error_f = []
error_s = []
error_h = []
def total_error1(sde_truth, sde, i0):
    summ = 0
    summ_ref = 0
    
    for i in range(t_size):
        summ += torch.sum(torch.abs( sde.f(ts[i], ys_truth[i]) - sde_truth.f(ts[i], ys_truth[i])))
        summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i])))# + torch.sum(torch.abs(sde.f(ts[i], ys_truth[i])))
                
    summ1 = 0
    summ1_ref = 0
    for i in range(t_size):
        s1 = sde_truth.g(ts[i], ys_truth[i])
        s2 = sde.g(ts[i], ys_truth[i])
        #if i0 > 50:
        #    print(s1, s2)
            #pdb.set_trace()
            
        for j in range(ys_truth.shape[1]):
            summ1_ref += torch.sum(torch.abs(s1[j])) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
            summ1 += torch.sum(torch.abs(torch.abs(s1[j]) - torch.abs(s2[j])))
            #summ1_ref += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)))) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
            #summ1 += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)) - torch.matmul(s2[j], s2[j].transpose(0, 1))))
    
    summ2 = 0
    summ2_ref = 0
    for i in range(t_size):
        h1 = sde_truth.h(ts[i], ys_truth[i])
        h2 = sde.h(ts[i], ys_truth[i])
        #if i0 > 50:
        #    print(s1, s2)
            #pdb.set_trace()
            
        for j in range(ys_truth.shape[1]):
            summ2_ref += torch.sum(torch.abs(h1[j])) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
            summ2 += torch.sum(torch.abs(h1[j] - h2[j]))
    
    print(summ / summ_ref, summ1 / summ1_ref, summ2 / summ2_ref, summ1_ref, summ2_ref)
    return float(summ / summ_ref), float(summ1 / summ1_ref), float(summ2 / summ2_ref)

sde.load_state_dict(torch.load('data/model' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + str(loss_type) + str(ini_noise_std) + '.pkl'))
ys = sdeint(sde, y0, ts).to(device)  
with torch.no_grad():
    ys = sdeint(sde, y0, ts).to(device)  

with torch.no_grad():
    f_error, s_error, h_error = total_error1(sde_truth, sde, 0)
    error_f.append(f_error)
    error_s.append(s_error)
    error_h.append(h_error)


loss_data = pd.DataFrame(data = error_f)
loss_data.to_csv('data/example1_f_error'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = error_s)
loss_data.to_csv('data/example1_s_error'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = error_h)
loss_data.to_csv('data/example1_h_error'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_'  + str(loss_type) + str(ini_noise_std) + '.csv', header=False, index = False)
