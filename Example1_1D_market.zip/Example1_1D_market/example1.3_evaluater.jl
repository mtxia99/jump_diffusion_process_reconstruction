using Distributed 
addprocs(5)
Σ = [i for i in 0.0:0.2:1.0]

@everywhere using ProgressMeter
@everywhere function execute(task)
    loss_type, i, σ = task
    cmd = `python example1_eval_y0_noise.py --loss=$(loss_type) --repeat=$(i) --ini_noise_std=$(σ)`
    # use pipe to capture the stdout and stderr to log/
    run(pipeline(
        cmd, 
        stdout="log/example1_$(loss_type)_$(repeat)_$(σ).out", 
        stderr="log/example1_$(loss_type)_$(repeat)_$(σ).err"))
end
tasks = [
    (loss_type, i, σ) for loss_type in ["w2_decoupled"],
    i ∈ 0:9,
    σ ∈ Σ
]
@info "tasks: $(tasks)"

progress_pmap(
    execute, tasks;
    progress = Progress(length(tasks), showspeed=true)
)