using CSV, DataFrames
using PGFPlotsX

loss_types = ["w2_decoupled"]
repeat_ids = 0:9
σ1s  = 0.2:0.04:0.4
σ2s = 0.5:0.1:1.0


function results_path(loss_type, repeat_id, σ1, σ2)
    ground_truth = "data/example1_ground_truth_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_langevin.csv"
    prediction = "data/example1_prediction_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_$(loss_type).csv"
    loss = "data/example1_loss2d_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_$(loss_type).csv"
    f_error = "data/example1_f_error_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_$(loss_type).csv"
    s_error = "data/example1_s_error_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_$(loss_type).csv"
    h_error = "data/example1_h_error_langevin_$(σ1)_$(σ2)_0_$(repeat_id)_$(loss_type).csv"
    return (ground_truth, prediction, loss, f_error, s_error, h_error)
end

function read_results(loss_type, repeat_id, σ1, σ2)
    ground_truth, prediction, loss, f_error, s_error, h_error = results_path(loss_type, repeat_id, σ1, σ2)
    ground_truth = CSV.read(ground_truth, header=false, DataFrame)
    prediction = CSV.read(prediction, header=false, DataFrame)
    loss = CSV.read(loss, header=false, DataFrame)
    f_error = CSV.read(f_error, header=false, DataFrame)
    s_error = CSV.read(s_error, header=false, DataFrame)
    h_error = CSV.read(h_error, header=false, DataFrame)
    # for loss and errors, keep the last row only
    loss = last(loss)
    f_error = last(f_error)
    s_error = last(s_error)
    h_error = last(h_error)
    return (ground_truth, prediction, loss, f_error, s_error, h_error)
end

# loss_type = "mse"
loss = DataFrame(loss=[], repeat_id=[], loss_type=[] , σ1=[], σ2=[])
s_error = DataFrame(s_error=[], repeat_id=[], loss_type=[], σ1=[], σ2=[])
f_error = DataFrame(f_error=[], repeat_id=[], loss_type=[], σ1=[], σ2=[])
h_error = DataFrame(h_error=[], repeat_id=[], loss_type=[], σ1=[], σ2=[])
for repeat_id in repeat_ids, loss_type in loss_types, σ1 in σ1s, σ2 in σ2s
    _, _, loss_i, f_error_i, s_error_i, h_error_i = read_results(loss_type, repeat_id, σ1, σ2)
    push!(loss, (loss_i[1], repeat_id, loss_type, σ1, σ2))
    push!(f_error, (f_error_i[1], repeat_id, loss_type, σ1, σ2))
    push!(s_error, (s_error_i[1], repeat_id, loss_type, σ1, σ2))
    push!(h_error, (h_error_i[1], repeat_id, loss_type, σ1, σ2))
end

# group by loss_type and compute mean and std
using Statistics
f_error_mean = combine(
    groupby(f_error, [:σ1, :σ2]), 
    :f_error => mean => :f_error_mean,
    :f_error => std => :f_error_std
)
s_error_mean = combine(
    groupby(s_error, [:σ1, :σ2]), 
    :s_error => mean => :s_error_mean,
    :s_error => std => :s_error_std
)
h_error_mean = combine(
    groupby(h_error, [:σ1, :σ2]), 
    :h_error => mean => :h_error_mean,
    :h_error => std => :h_error_std
)
loss_mean = combine(
    groupby(loss, [:σ1, :σ2]), 
  :loss => mean => :loss_mean,
    :loss => std => :loss_std
)

# horizontally join the mean and std of loss and errors
result_df = DataFrame(
    σ1 = loss_mean.σ1,
    σ2 = loss_mean.σ2,
    loss_mean=loss_mean.loss_mean,
    loss_std=loss_mean.loss_std,
    f_error_mean=f_error_mean.f_error_mean,
    f_error_std=f_error_mean.f_error_std,
    s_error_mean=s_error_mean.s_error_mean,
    s_error_std=s_error_mean.s_error_std,
    h_error_mean=h_error_mean.h_error_mean,
    h_error_std=h_error_mean.h_error_std
)

# Row │ loss_type     loss_mean  loss_std   f_error_mean  f_error_std  s_error_mean  s_error_std  h_error_mean  h_error_std 
# │ String        Float64    Float64    Float64       Float64      Float64       Float64      Float64       Float64     
# ─────┼─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
# 1 │ mse            0.847071  0.0365444     0.0883808    0.039166       0.998116   0.00261816      0.978358    0.0193719
# 2 │ mean2_var      5.7317    0.715791      0.165236     0.110019       0.541958   0.408701        0.571974    0.386415
# 3 │ w2_decoupled   5.53387   0.886639      0.124865     0.0535461      0.289539   0.185003        0.285039    0.321729
# 4 │ w2_coupled    64.6946    2.47168       0.304583     0.0583607      0.964244   0.0397017       0.532491    0.0777483
# bar plot of errors, x symbolic coordinate: different loss types
# y: mean of errors, error bar: std of errors
using DataFrames, PGFPlotsX

# Assuming `result_df` DataFrame is already defined with your data

# Prepare the data for plotting
# This step is already completed based on your description

# Plotting
xmin = minimum(σ1s)
xmax = maximum(σ1s)
xstep = (xmax - xmin) / (length(σ1s) - 1)
@show xmin_axis = xmin - xstep / 2
@show xmax_axis = xmax + xstep / 2
ymin = minimum(σ2s)
ymax = maximum(σ2s)
ystep = (ymax - ymin) / (length(σ2s) - 1)
@show ymin_axis = ymin - ystep / 2
@show ymax_axis = ymax + ystep / 2    

tikzpicture = @pgf TikzPicture({"baseline"})
axis =@pgf Axis(
    {
        width = "3.4in",
        height = "3.4in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "\$ \\sigma_1 \$",
        ylabel = "\$ \\sigma_2 \$",
        # use colormap
        # colormap = "viridis",
        colorbar,
        title="\\Large loss",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        # point_meta_min = 0,
        # set x tikcs to be the same as σ1s 
        xtick = "{$(join(σ1s, ", "))}",
        xmin = xmin_axis,
        xmax = xmax_axis,
        ymin = ymin_axis,
        ymax = ymax_axis,
        # ymax=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(a)};"
        },
    },
    Plot3({
        "matrix plot*",
        "mesh/rows" = length(σ1s),
        "mesh/cols" = length(σ2s),
    }, Table(
        result_df.σ1,
        result_df.σ2,
        result_df.loss_mean * 0.2
    ))
    )
push!(tikzpicture, axis)

pgfsave("example1_var_errors.tex", axis,include_preamble = true)
pgfsave("example1_var_errors.pgf", axis,include_preamble = false)
# This code will create an Axis object which can be displayed in a Jupyter notebook
# or saved to a file using `pgfsave("myplot.tex", axis_object, include_preamble = true)`.
# run(`tex2eps example1_var_errors.tex`)

# Plot f_errors
tikzpicture = @pgf TikzPicture({"baseline"})
axis =@pgf Axis(
    {
        width = "3.4in",
        height = "3.4in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "\$ \\sigma_1 \$",
        # ylabel = "\$ \\sigma_2 \$",
        # use colormap
        # colormap = "viridis",
        # colorbar,
        yticklabel={},
        title="\\Large drift function error",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        xtick = "{$(join(σ1s, ", "))}",
        xmin = xmin_axis,
        xmax = xmax_axis,
        ymin = ymin_axis,
        ymax = ymax_axis,
        point_meta_min=0,
        point_meta_max=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(b)};"
        },
    },
    Plot3({
        "matrix plot*",
        shader = "flat",
        "mesh/rows" = length(σ1s),
        "mesh/cols" = length(σ2s),
    }, Table(
        result_df.σ1,
        result_df.σ2,
        result_df.f_error_mean
    ))
    )
push!(tikzpicture, axis)

pgfsave("example1_var_f_errors.tex", axis,include_preamble = true)
pgfsave("example1_var_f_errors.pgf", axis,include_preamble = false)
# This code will create an Axis object which can be displayed in a Jupyter notebook
# or saved to a file using `pgfsave("myplot.tex", axis_object, include_preamble = true)`.
# run(`tex2eps example1_var_f_errors.tex`)

# Plot s_errors
tikzpicture = @pgf TikzPicture({"baseline"})
axis = @pgf Axis(
    {
        width = "3.4in",
        height = "3.4in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "\$ \\sigma_1 \$",
        # ylabel = "\$ \\sigma_2 \$",
        # use colormap
        # colormap = "viridis",
        # colorbar,
        yticklabel={},
        title="\\Large diffusion function error",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        xtick = "{$(join(σ1s, ", "))}",
        xmin = xmin_axis,
        xmax = xmax_axis,
        ymin = ymin_axis,
        ymax = ymax_axis,
        point_meta_min=0,
        point_meta_max=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(c)};"
        },
    },
    Plot3({
        "matrix plot*",
        "mesh/rows" = length(σ1s),
        "mesh/cols" = length(σ2s),
    }, Table(
        result_df.σ1,
        result_df.σ2,
        result_df.s_error_mean
    ))
    )
push!(tikzpicture, axis)

pgfsave("example1_var_s_errors.tex", axis,include_preamble = true)
pgfsave("example1_var_s_errors.pgf", axis,include_preamble = false)
# run(`tex2eps example1_var_s_errors.tex`)

# Plot h_errors
tikzpicture = @pgf TikzPicture({"baseline"})
axis = @pgf Axis(
    {
        width = "3.4in",
        height = "3.4in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "\$ \\sigma_1 \$",
        # ylabel = "\$ \\sigma_2 \$",
        yticklabel={},
        # use colormap
        # colormap = "viridis",
        colorbar,
        title="\\Large jump function error",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        xtick = "{$(join(σ1s, ", "))}",
        xmin = xmin_axis,
        xmax = xmax_axis,
        ymin = ymin_axis,
        ymax = ymax_axis,
        point_meta_min=0,
        point_meta_max=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(d)};"
        },
    },
    Plot3({
        "matrix plot*",
        "mesh/rows" = length(σ1s),
        "mesh/cols" = length(σ2s),
    }, Table(
        result_df.σ1,
        result_df.σ2,
        result_df.h_error_mean
    ))
    )

push!(tikzpicture, axis)

pgfsave("example1_var_h_errors.tex", axis,include_preamble = true)
pgfsave("example1_var_h_errors.pgf", axis,include_preamble = false)
# run(`tex2eps example1_var_h_errors.tex`)