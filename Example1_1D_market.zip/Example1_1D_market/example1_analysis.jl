using CSV, DataFrames
using PGFPlotsX

loss_types = [
    "w2_decoupled", "w2_coupled", "mmd",
    "mse", "mean2_var", "w1_coupled","wgan"]
repeat_ids = 0:9

function results_path(loss_type, repeat_id)
    ground_truth = "data/example1_ground_truth_langevin_0.4_0_$(repeat_id)_langevin.csv"
    prediction = "data/example1_prediction_langevin_0.4_0_$(repeat_id)_$(loss_type).csv"
    loss = "data/example1_loss2d_langevin_0.4_0_$(repeat_id)_$(loss_type).csv"
    f_error = "data/example1_f_error_langevin_0.4_0_$(repeat_id)_$(loss_type).csv"
    s_error = "data/example1_s_error_langevin_0.4_0_$(repeat_id)_$(loss_type).csv"
    h_error = "data/example1_h_error_langevin_0.4_0_$(repeat_id)_$(loss_type).csv"
    return (ground_truth, prediction, loss, f_error, s_error, h_error)
end

function read_results(loss_type, repeat_id)
    ground_truth, prediction, loss, f_error, s_error, h_error = results_path(loss_type, repeat_id)
    ground_truth = CSV.read(ground_truth, header=false, DataFrame)
    # prediction = CSV.read(prediction, header=false, DataFrame)
    # loss = CSV.read(loss, header=false, DataFrame)
    f_error = CSV.read(f_error, header=false, DataFrame)
    s_error = CSV.read(s_error, header=false, DataFrame)
    h_error = CSV.read(h_error, header=false, DataFrame)
    # for loss and errors, keep the last row only
    # loss = last(loss)
    f_error = last(f_error)
    s_error = last(s_error)
    h_error = last(h_error)
    prediction = nothing # not used
    return (ground_truth, prediction, nothing, f_error, s_error, h_error)
end

# loss_type = "mse"
# loss = DataFrame(loss=[], repeat_id=[], loss_type=[])
s_error = DataFrame(s_error=[], repeat_id=[], loss_type=[])
f_error = DataFrame(f_error=[], repeat_id=[], loss_type=[])
h_error = DataFrame(h_error=[], repeat_id=[], loss_type=[])
for repeat_id in repeat_ids, loss_type in loss_types
    if isfile(results_path(loss_type, repeat_id)[1]) == false
        continue
    end
    _, _, loss_i, f_error_i, s_error_i, h_error_i = read_results(loss_type, repeat_id)
    # push!(loss, (loss_i[1], repeat_id, loss_type))
    push!(f_error, (f_error_i[1], repeat_id, loss_type))
    push!(s_error, (s_error_i[1], repeat_id, loss_type))
    push!(h_error, (h_error_i[1], repeat_id, loss_type))
end

# group by loss_type and compute mean and std
using Statistics
f_error_mean = combine(
    groupby(f_error, :loss_type), 
    :f_error => mean => :f_error_mean,
    :f_error => std => :f_error_std
)
s_error_mean = combine(
    groupby(s_error, :loss_type), 
    :s_error => mean => :s_error_mean,
    :s_error => std => :s_error_std
)
h_error_mean = combine(
    groupby(h_error, :loss_type), 
    :h_error => mean => :h_error_mean,
    :h_error => std => :h_error_std
)
# loss_mean = combine(
#     groupby(loss, :loss_type), 
#     :loss => mean => :loss_mean,
#     :loss => std => :loss_std
# )

# horizontally join the mean and std of loss and errors
result_df = DataFrame(
    loss_type=loss_types,
    # loss_mean=loss_mean.loss_mean,
    # loss_std=loss_mean.loss_std,
    f_error_mean=f_error_mean.f_error_mean,
    f_error_std=f_error_mean.f_error_std,
    s_error_mean=s_error_mean.s_error_mean,
    s_error_std=s_error_mean.s_error_std,
    h_error_mean=h_error_mean.h_error_mean,
    h_error_std=h_error_mean.h_error_std
)

# Row │ loss_type     loss_mean  loss_std   f_error_mean  f_error_std  s_error_mean  s_error_std  h_error_mean  h_error_std 
# │ String        Float64    Float64    Float64       Float64      Float64       Float64      Float64       Float64     
# ─────┼─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
# 1 │ mse            0.847071  0.0365444     0.0883808    0.039166       0.998116   0.00261816      0.978358    0.0193719
# 2 │ mean2_var      5.7317    0.715791      0.165236     0.110019       0.541958   0.408701        0.571974    0.386415
# 3 │ w2_decoupled   5.53387   0.886639      0.124865     0.0535461      0.289539   0.185003        0.285039    0.321729
# 4 │ w2_coupled    64.6946    2.47168       0.304583     0.0583607      0.964244   0.0397017       0.532491    0.0777483
# bar plot of errors, x symbolic coordinate: different loss types
# y: mean of errors, error bar: std of errors
using DataFrames, PGFPlotsX

# Assuming `result_df` DataFrame is already defined with your data

# Prepare the data for plotting
# This step is already completed based on your description

# Plotting
# replace _ by \_ in the loss type
# function to cap data at 1
function cap_at_1(x)
    if x > 2
        return 2
    else
        return x
    end
end

pretty_loss_types = [
    "\$W_2~\$decoupled",
    "\$W_2~\$coupled",
    "MMD",
    "MSE",
    "mean\$^2\$+var",
    "\$W_1~\$coupled",
    "WGAN",
]
tikzpicture = @pgf TikzPicture({"baseline"})
axis =@pgf Axis(
    {
        ybar,
        width = "12cm",
        height = "8cm",
        # ybar = "5pt",  # Distance between bars
        bar_width = "8pt",
        enlarge_x_limits = 0.2,
        legend_style = {at = "{(0.5, 1.0)}", anchor = "north", legend_columns = -1},
        ylabel = "error",
        # xlabel = "loss",
        symbolic_x_coords = pretty_loss_types,
        xtick = "data",
        xticklabel_style = {rotate = 45, anchor = "east"},
        # nodes_near_coords_align = {"vertical"},
        # nodes_near_coords,
        ymin = 0,  # Adjust based on your data
        ymax = 2,  # Adjust based on your data
    },
    PlotInc(
        {fill = "blue", "error bars/.cd", y_dir = "both", y_explicit},
         Table({
            "x = x",
            "y = y",
            "y error = y_error"
         },[
            "x" => pretty_loss_types,
            "y" =>  cap_at_1.(result_df.f_error_mean),
            "y_error" => cap_at_1.( result_df.f_error_std),
        ]),
    ),
    PlotInc(
        {fill = "red", "error bars/.cd", y_dir = "both", y_explicit},
         Table({
            "x = x",
            "y = y",
            "y error = y_error"
         },            [
            "x" => pretty_loss_types,
            "y" =>  cap_at_1.(result_df.s_error_mean),
            "y_error" => cap_at_1.( result_df.s_error_std),
        ]),
    ),
    PlotInc(
        {fill = "green", "error bars/.cd", y_dir = "both", y_explicit},
         Table({
            "x = x",
            "y = y",
            "y error = y_error"
         },[
            "x" => pretty_loss_types,
            "y" => cap_at_1.(result_df.h_error_mean),
            "y_error" => cap_at_1.(result_df.h_error_std),
        ]),
    ),
    Legend(["\$f\$ error", "\$s\$ error", "\$h\$ error"])
)
push!(tikzpicture, axis)

pgfsave("example1_errors.tex", axis,include_preamble = true)
# This code will create an Axis object which can be displayed in a Jupyter notebook
# or saved to a file using `pgfsave("myplot.tex", axis_object, include_preamble = true)`.
run(`tex2eps example1_errors.tex`)