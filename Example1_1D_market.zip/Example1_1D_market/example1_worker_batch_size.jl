using Distributed 
addprocs([("asrock", 5), ("rackmount", 2)])


@everywhere using ProgressMeter
@everywhere function execute(task)
    loss_type, i, batch_size = task
    cmd = `python example1_base_batch_size.py --loss=$(loss_type) --repeat=$(i) --batch_size=$(batch_size)`
    # use pipe to capture the stdout and stderr to log/
    run(pipeline(
        cmd, 
        stdout="log/example1_$(loss_type)_$(i)_$(batch_size).out", 
        stderr="log/example1_$(loss_type)_$(i)_$(batch_size).err"))
end
tasks = [
    (loss_type, i, batch_size) for loss_type in ["w2_decoupled", "w2_coupled", "mmd", "mse", "mean2_var", "w1_coupled"],
    i ∈ 0:9, batch_size in [128]
]

progress_pmap(
    execute, tasks;
    progress = Progress(length(tasks), showspeed=true)
)
