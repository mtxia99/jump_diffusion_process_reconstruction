#!/bin/bash

# Loop over repeat values from 0 to 9
for repeat in {0..9}
do
    echo "Running with repeat=$repeat"
    python example1_base_batch_size_wgan.py --batch_size=8 --repeat=$repeat
done

