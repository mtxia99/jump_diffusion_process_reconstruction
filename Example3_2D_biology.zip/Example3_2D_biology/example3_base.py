import torch
from torchsde_master_homogeneous import *
from torchsde_master_homogeneous.torchsde._core.sdeint import *
import pandas as pd
import random
import time
import pdb
import csv
from tqdm import tqdm
from math import sqrt
from math import sqrt
import sys
sys.setrecursionlimit(5000)
torch.set_num_threads(1)

device = torch.device("cpu" if torch.cuda.is_available() else "cpu")

batch_size, state_size, brownian_size, levy_size = 300, 2, 2, 2
H = 400
t_size = 51
print(device)
class TwoLayerNet(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        """
        In the constructor we instantiate two nn.Linear modules and assign them as
        member variables.
        """
        super(TwoLayerNet, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H)
        self.linear2 = torch.nn.Linear(H, H)
        self.linear3 = torch.nn.Linear(H, D_out)
        
        #return data
    
    def forward(self, x):
        """
        In the forward function we accept a Tensor of input data and we must return
        a Tensor of output data. We can use Modules defined in the constructor as
        well as arbitrary operators on Tensors.
        """
        h_relu1 = self.linear1(x)
        h_relu1 = torch.relu(h_relu1)
        h_relu2 = self.linear2(h_relu1)
        h_relu2 = torch.relu(h_relu2)
        y_pred = self.linear3(h_relu2)
        return y_pred
from math import pi    
import gc
        
import ot

def custom_init_weights(m):
    if isinstance(m, torch.nn.Linear):
        # Initialize weights with a normal distribution and biases with zeros
        torch.nn.init.normal_(m.weight, mean=0, std=0.01)
        torch.nn.init.zeros_(m.bias)
        


def distance(P, Q):
    cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
    return cost_matrix

def w2_decoupled(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    for i in range(1, t_size):
        weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)

        loss += ot.emd2(weights, weights, distance(y[i, :, :], y_pred[i, :, :]))
    
    return loss

def w2_coupled(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    y_coupled = torch.zeros(batch_size, state_size * t_size)
    y_pred_coupled = torch.zeros(batch_size, state_size * t_size)
    for i in range(0, t_size):
        y_coupled[:, i*state_size:(i+1)*state_size] += y[i, :, :]
        y_pred_coupled[:, i*state_size:(i+1)*state_size] += y_pred[i, :, :]
    
    weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)

    loss += ot.emd2(weights, weights, distance(y_coupled[:, :], y_pred_coupled[:, :]))
    
    return loss


def run_cor(cor1, cor2):
    
    params = [0.25, 0.21]
    #params = [0, 1]
    class SDE(torch.nn.Module):
        noise_type = 'general'
        sde_type = 'ito'
    
        def __init__(self):
            super().__init__()
            self.mu = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size)
            self.sigma = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size * brownian_size)#torch.nn.Linear(state_size, 
                                         #state_size * brownian_size)
            self.jump = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size * levy_size)#torch.nn.Linear(state_size, 
                                         #state_size * brownian_size)
    
        # Drift
        def f(self, t, y):
            #print(y.shape)
            f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
            #for i in range(y.shape[0]):
            N1 = 1 / sqrt(2*pi*sigma_set[0]**2) * torch.exp(-(y[:, 0]-mu_set[0][0])**2/2/sigma_set[0]**2 - 
                                                          (y[:, 1]-mu_set[0][1])**2/2/sigma_set[0]**2)
            N2 = 1 / sqrt(2*pi*sigma_set[1]**2) * torch.exp(-(y[:, 0]-mu_set[1][0])**2/2/sigma_set[1]**2 - 
                                                          (y[:, 1]-mu_set[1][1])**2/2/sigma_set[1]**2)
            
            #print(N1, N2)
            #pdb.set_trace()
            f_truth[:, 0] = -1/sigma_set[0] * N1 / (N1+N2) * (y[:, 0] - mu_set[0][0]) - 1/sigma_set[1] * N2 / (N1+N2) * (y[:, 0] - mu_set[1][0])
            f_truth[:, 1] = -1/sigma_set[1] * N1 / (N1+N2) * (y[:, 1] - mu_set[0][1]) - 1/sigma_set[1] * N2 / (N1+N2) * (y[:, 1] - mu_set[1][1])
            #print(f_truth)    
            #pdb.set_trace()    
            return f_truth  # shape (batch_size, state_size)
        
        #def f(self, t, y):
        #    t = t.expand(y.size(0), 1)
        #    ty = torch.cat([t, y], dim=1).to(device)
    
            #f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
            #for i in range(y.shape[0]):
            #    f_truth[i, 0] = -params[0]*y[i, 0] - params[1]*y[i, 1]# - y[i, 1]
            #    f_truth[i, 1] = params[1]*y[i, 0] - params[0]*y[i, 1]#y[i, 0]
                
        #    return self.mu(y)  # shape (batch_size, state_size)
    
        # Diffusion
        def g(self, t, y):
            t = t.expand(y.size(0), 1)
            ty = torch.cat([t, y], dim=1).to(device)
            sigma_matrix = self.sigma(y).view(batch_size, 
                                      state_size, 
                                      brownian_size)
            
            #sigma_result = torch.zeros(batch_size, state_size, brownian_size)
            #sigma_result[:, 0, 0] = sigma_matrix[:, 0, 0]
            #sigma_result[:, 0, 1] = sigma_matrix[:, 1, 1] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 0] = -sigma_matrix[:, 0, 0] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 1] = sigma_matrix[:, 1, 1]
            #print(sigma_result[1, :, :])
            #pdb.set_trace()
            #for i in range(y.shape[0]):
            #    sigma_matrix[i, 0, 1] = 0
            #    sigma_matrix[i, 1, 0] = 0
            return sigma_matrix#self.sigma(y).view(batch_size, 
                                #      state_size, 
                                 #     brownian_size)
        
        #def h(self, t, y):
        ##    global noise_type
            #h_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
            #for i in range(y.shape[0]):
            #    if noise_type == 'const':
            #        
            #        h_truth[i, 0, 0] = sigma_para #sqrt(abs(params[0]*y[i, 0])) #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
            #    elif noise_type == 'linear':
            #        h_truth[i, 0, 0] = sigma_para * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x * abs(y[i, 0])
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para * y[i, 1]
            #    elif noise_type == 'langevin':
            #        h_truth[i, 0, 0] = sigma_para * sqrt(abs(y[i, 0])) #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x * sqrt(abs(y[i, 0]))
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para * x * sqrt(abs(y[i, 1]))
                
                
            #return h_truth * sigma_para * 0 / 5
        
        def h(self, t, y):
        #    t = t.expand(y.size(0), 1)
        #    ty = torch.cat([t, y], dim=1).to(device)
            jump_matrix = self.jump(y).view(batch_size, 
                                      state_size, 
                                      levy_size)
            
            #sigma_result = torch.zeros(batch_size, state_size, brownian_size)
            #sigma_result[:, 0, 0] = sigma_matrix[:, 0, 0]
            #sigma_result[:, 0, 1] = sigma_matrix[:, 1, 1] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 0] = -sigma_matrix[:, 0, 0] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 1] = sigma_matrix[:, 1, 1]
            #print(sigma_result[1, :, :])
            #pdb.set_trace()
            #for i in range(y.shape[0]):
            #    sigma_matrix[i, 0, 1] = 0
            #    sigma_matrix[i, 1, 0] = 0
            return jump_matrix#self.sigma(y).view(batch_size, 
        
    

    from math import sqrt
    print('start')
    #
    # for each sigma = 0.02:0.02:0.18, each cor=-1:-.25:1
    # for each noise type const, linear, langevin
    # repeat 10 experiments, a total of 810 models 
    # sigma_para = 0.05#0.1:0.05:0.5
    global sigma_para
    global sigma_para2
    #cor1 = 0.5 #-1:-.25:1
    if cor1 == 0:
        x = 0
    else:
        x = cor1#(2 - sqrt(4 - 4 * cor1**2)) / 2 / cor1
        
    #cor1 = -0.5 #-1:-.25:1
    if cor2 == 0:
        x1 = 0
    else:
        x1 = cor2
    
    from math import pi, sqrt, exp
    Sigma = [[0.1, -0.05], [-0.05, 0.05]]
    global noise_type
    #noise_type = 'linear'
    # noise_type2 = 'langevin'
    global noise_type2
    sigma_set = [1, 0.95]
    #mu_set = [[16, 12], [-18, -10]]
    mu_set = [[1.6, 1.2], [1.8, 1.0]]
    class SDE_truth(torch.nn.Module):
        noise_type = 'general'
        sde_type = 'ito'
        
        def __init__(self):
            super().__init__()
    
    
        # Drift
        def f(self, t, y):
            #print(y.shape)
            f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
            for i in range(y.shape[0]):
                N1 = 1 / sqrt(2*pi*sigma_set[0]**2) * exp(-(y[i, 0]-mu_set[0][0])**2/2/sigma_set[0]**2 - 
                                                          (y[i, 1]-mu_set[0][1])**2/2/sigma_set[0]**2)
                N2 = 1 / sqrt(2*pi*sigma_set[1]**2) * exp(-(y[i, 0]-mu_set[1][0])**2/2/sigma_set[1]**2 - 
                                                          (y[i, 1]-mu_set[1][1])**2/2/sigma_set[1]**2)
                f_truth[i, 0] = -1/sigma_set[0] * N1 / (N1+N2) * (y[i, 0] - mu_set[0][0]) - 1/sigma_set[1] * N2 / (N1+N2) * (y[i, 0] - mu_set[1][0])
                f_truth[i, 1] = -1/sigma_set[1] * N1 / (N1+N2) * (y[i, 1] - mu_set[0][1]) - 1/sigma_set[1] * N2 / (N1+N2) * (y[i, 1] - mu_set[1][1])
                
                
            return f_truth  # shape (batch_size, state_size)
    
        # Diffusion
        def g(self, t, y):
            global noise_type
            g_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
            for i in range(y.shape[0]):
                if noise_type == 'const':
                    g_truth[i, 0, 1] = sigma_para #sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    g_truth[i, 1, 0] = sigma_para * x
                    g_truth[i, 0, 1] = sigma_para * x#-sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    g_truth[i, 1, 1] = sigma_para #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
                elif noise_type == 'linear':
                    g_truth[i, 0, 0] = sigma_para * y[i, 0] #* sqrt(t+1)
                    g_truth[i, 0, 1] = sigma_para * x * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    g_truth[i, 1, 0] = sigma_para * x * abs(y[i, 0])
                    #g_truth[i, 0, 1] = sigma_para * x * abs(y[i, 0])#-sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    g_truth[i, 1, 1] = sigma_para * y[i, 1]
                elif noise_type == 'langevin':
                    g_truth[i, 0, 0] = sigma_para * sqrt(abs(y[i, 0])) #* sqrt(t+1)
                    g_truth[i, 0, 1] = sigma_para * x * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    g_truth[i, 1, 0] = sigma_para * x * sqrt(abs(y[i, 0]))
                    ##g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    g_truth[i, 1, 1] = sigma_para * sqrt(abs(y[i, 1]))
                
                
            return g_truth #* sigma_para
        
        def h(self, t, y):
            global noise_type2
            h_truth = torch.zeros(y.shape[0], y.shape[1], levy_size).to(device)
            for i in range(y.shape[0]):
                if noise_type2 == 'const':
                    
                    h_truth[i, 0, 0] = sigma_para2 #sqrt(abs(params[0]*y[i, 0])) #* sqrt(t+1)
                    h_truth[i, 0, 1] = sigma_para2 * x1#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    h_truth[i, 1, 0] = sigma_para2 * x1
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    h_truth[i, 1, 1] = sigma_para2 #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
                elif noise_type2 == 'linear':
                    h_truth[i, 0, 0] = sigma_para2 * abs(y[i, 0]) #* sqrt(t+1)
                    h_truth[i, 0, 1] = sigma_para2 * x1 * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    h_truth[i, 1, 0] = sigma_para2 * x1 * abs(y[i, 0])
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    h_truth[i, 1, 1] = sigma_para2 * abs(y[i, 1])
                elif noise_type2 == 'langevin':
                    h_truth[i, 0, 0] = sigma_para2 * sqrt(abs(y[i, 0]))#* sqrt(abs(y[i, 0])) #* sqrt(t+1)
                    h_truth[i, 0, 1] = sigma_para2 * x1 * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    h_truth[i, 1, 0] = sigma_para2 * x1 * sqrt(abs(y[i, 0]))
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    h_truth[i, 1, 1] = sigma_para2 * sqrt(abs(y[i, 1]))
                
                
            return h_truth #* sigma_para / 2 
    global repeat    
    sde = SDE().to(device)
    sde.apply(custom_init_weights)
    sde_truth = SDE_truth().to(device)   
    y0 = torch.zeros(batch_size, state_size).to(device)
    for i in range(batch_size):
        if i < 100:
            y0[i, 0] = 1.7#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
            y0[i, 1] = 1.1
        else:
            y0[i, 0] = 1.7#0.5 #+ float(torch.randn(1)[0] *0.5)
            y0[i, 1] = 1.1
            
        if y0[i, 0] < 0:
            print("error")
            
    t_end = 10#10
    ts = torch.linspace(0, t_end, t_size).to(device)
    
    ys_truth = sdeint(sde_truth, y0, ts).to(device)
    print('start')
    truth_data1 = pd.DataFrame(data = [[float(ys_truth[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
    truth_data1.to_csv('data/example3_ground_truth_d1' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor1) + '_' + str(cor2)+ '_' + str(repeat) + '.csv', header=False, index = False)
    
    truth_data2 = pd.DataFrame(data = [[float(ys_truth[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
    truth_data2.to_csv('data/example3_ground_truth_d2' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor1) + '_' + str(cor2)+ '_' + str(repeat) + '.csv', header=False, index = False)
    
    #print(sde.parameters())
    #pdb.set_trace()
    optimizer = torch.optim.Adam(sde.parameters(), lr=0.002,betas= (0.9, 0.999), weight_decay=0.005)
    epoch = 400
    loss_list = []
    ttime = time.time()

    
            
    


    error_f = []
    error_s = []
    error_h = []
    def total_error1(sde_truth, sde, i0):            
        summ = 0
        summ_ref = 0
        
        for i in range(t_size):
            summ += torch.sum(torch.abs( sde.f(ts[i], ys[i]) - sde_truth.f(ts[i], ys[i])))
            summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys[i])))# + torch.sum(torch.abs(sde.f(ts[i], ys_truth[i])))
                    
        summ1 = 0
        summ1_ref = 0
        for i in range(t_size):
            s1 = sde_truth.g(ts[i], ys[i])
            s2 = sde.g(ts[i], ys[i])
            #if i0 > 50:
            #    print(s1, s2)
                #pdb.set_trace()
                
            for j in range(ys.shape[1]):
                summ1_ref += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)))) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
                summ1 += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)) - torch.matmul(s2[j], s2[j].transpose(0, 1))))
        
        summ2 = 0
        summ2_ref = 0
        for i in range(t_size):
            h1 = sde_truth.h(ts[i], ys[i])
            h2 = sde.h(ts[i], ys[i])
            #if i0 > 50:
            #    print(s1, s2)
                #pdb.set_trace()
                
            for j in range(ys.shape[1]):
                summ2_ref += torch.sum(torch.abs(torch.matmul(h1[j], h1[j].transpose(0, 1))))#torch.sum(torch.abs(torch.abs(h1[j]))) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
                summ2 += torch.sum(torch.sum(torch.abs(torch.matmul(h1[j], h1[j].transpose(0, 1)) - torch.matmul(h2[j], h2[j].transpose(0, 1)))))
        
        print(summ / summ_ref, summ1 / summ1_ref, summ2 / summ2_ref)
        return float(summ / summ_ref), float(summ1 / summ1_ref), float(summ2 / summ2_ref) 
  
    for i0 in tqdm(range(epoch)):
        #print(i)
        ys = sdeint(sde, y0, ts).to(device)  
        #print(ys)
        #pdb.set_trace()
        loss =  w2_decoupled(ys, ys_truth)
    
        if i0 % 10 == 0:
            print(i0, loss.item(), time.time() - ttime, cor1, cor2, batch_size, sigma_para)
            f_error, s_error, h_error = total_error1(sde_truth, sde, i0)
            error_f.append(f_error)
            error_s.append(s_error)
            error_h.append(h_error)
            ttime = time.time()
            
        loss_list.append(loss.item())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if i0 != epoch - 1:
            del ys
            del loss
            gc.collect()    
    
    torch.save(sde.state_dict(), 'data/example3_model' + '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +'.pkl')
    predict_data = pd.DataFrame(data = [[float(ys[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
    predict_data.to_csv('data/example3_predict_d1' + '_' + noise_type + '_' + noise_type2 + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    
    predict_data = pd.DataFrame(data = [[float(ys[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
    predict_data.to_csv('data/example3_predict_d2'+ '_' + noise_type + '_' + noise_type2 + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = loss_list)
    loss_data.to_csv('data/example3_loss'+ '_' + noise_type + '_' + noise_type2 + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    
    # loss_data = pd.DataFrame(data = error_f)
    # loss_data.to_csv('coupled_f_error_cir_damped2cuda'+ '_' + noise_type + '_' + noise_type2 + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    
    # loss_data = pd.DataFrame(data = error_s)
    # loss_data.to_csv('coupled_s_error_cir_damped2cuda'+ '_' + noise_type + '_' + noise_type2 + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    
    # loss_data = pd.DataFrame(data = error_h)
    # loss_data.to_csv('coupled_h_error_cir_damped2cuda'+ '_' + noise_type + '_' + noise_type2 + str(cor1) + str(cor2) + '_' + str(repeat) +  '.csv', header=False, index = False)
    return error_f[-1], error_s[-1], error_h[-1]
    
# Correlation1 = [-1, -0.5, 0, 0.5, 1]
# Correlation2 = [-1, -0.5, 0, 0.5, 1]
# F_list = [[0 for j in range(5)] for i in range(5)]
# S_list = [[0 for j in range(5)] for i in range(5)]
# H_list = [[0 for j in range(5)] for i in range(5)]
    
# use argparse to get correlation1 and correlation2
import argparse
parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('--cor1', type=float, help='correlation1')
parser.add_argument('--cor2', type=float, help='correlation2')
parser.add_argument('--repeat', type=int, help='repeat')
parser.add_argument('--noise_type', type=str, help='noise_type')
parser.add_argument('--noise_type2', type=str, help='noise_type2')
parser.add_argument('--sigma1', type=float, help='sigma_para')
parser.add_argument('--sigma2', type=float, help='sigma_para2')
args = parser.parse_args()
cor1 = args.cor1
cor2 = args.cor2
repeat = args.repeat
noise_type = args.noise_type
noise_type2 = args.noise_type2
sigma_para = args.sigma1
sigma_para2 = args.sigma2
# print the arguments
print(cor1, cor2, repeat, noise_type, noise_type2, sigma_para, sigma_para2)

# check if 'data/example3_result'+ '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) + '.csv'
# exists, if yes, skip the calculation
import os
if os.path.exists('data/example3_result'+ '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) + '.csv'):
    print('data/example3_result'+ '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) + '.csv exists')
    exit()

f_error, s_error, h_error = run_cor(cor1, cor2)

dict_data = {'f_error': f_error, 's_error': s_error, 'h_error': h_error, 'cor1': cor1, 'cor2': cor2, 'repeat': repeat, 'noise_type': noise_type, 'noise_type2': noise_type2, 'sigma_para': sigma_para, 'sigma_para2': sigma_para2}

# save the data to csv by pandas
import pandas as pd
df = pd.DataFrame(dict_data, index=[0])
df.to_csv('data/example3_result'+ '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(sigma_para) + '_' + str(sigma_para2) + '_' + str(repeat) + '.csv', header=True, index = False)
