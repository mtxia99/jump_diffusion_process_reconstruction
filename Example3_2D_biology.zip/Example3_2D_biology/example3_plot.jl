using CSV, DataFrames, PGFPlotsX
################# W2 decoupled #################
# path to ground truth
gt1 = CSV.read("data/example3_ground_truth_d1_langevin_0.1_-0.5_-0.5_1.csv", DataFrame; header=false)
gt2 = CSV.read("data/example3_ground_truth_d2_langevin_0.1_-0.5_-0.5_1.csv", DataFrame; header=false)
# each column is a time point,
# each row is a sample
ts = 0:0.1:5 |> collect
tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "time \$ t \$",
        ylabel = "\$X_1(t)\$",
        width = "3in",
        height = "3in",
        # ymin=2,
        # ymax=9.9,
        enlarge_y_limits = 0.2,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(a)};"
        },
    }
)

for j in 1:20
xs = [gt1[j,i] for i in 1:size(gt1,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "black",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else 
push!(axis, @pgf PlotInc(
    {
        color = "black",
        mark = "none",
    },
    Table(ts, xs)
))
end
end

    
axis

# path to prediction
pred1 = CSV.read("data/example3_predict_d1_langevin_const-0.5_-0.5_0.1_0.1_1.csv", DataFrame; header=false)
pred2 = CSV.read("data/example3_predict_d2_langevin_const-0.5_-0.5_0.1_0.1_1.csv", DataFrame; header=false)
# same format
for j in 1:20
xs = [pred1[j,i] for i in 1:size(pred1,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
        mark_repeat = 10,
        forget_plot = true,
    },
    Table(ts, xs)
))
else
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
        mark_repeat = 10,
    },
    Table(ts, xs)
))
end
end
    
# add legend 
push!(axis, @pgf LegendEntry("\$X_1(t)\$ ground truth"))
push!(axis, @pgf LegendEntry("\$X_1(t)\$ prediction"))
axis
push!(tikzpicture, axis)
pgfsave("example3_plot_a.pgf", tikzpicture)   

tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "time \$ t \$",
        ylabel = "\$X_2(t)\$",
        width = "3in",
        height = "3in",
        # ymin=2,
        # ymax=9.9,
        enlarge_y_limits = 0.2,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(b)};"
        },
    }
)
for j in 1:20
    xs = [gt2[j,i] for i in 1:size(gt2,2)]
    if j ≠ 1
    push!(axis, @pgf PlotInc(
        {
            color = "black",
            mark = "none",
            forget_plot = true,
        },
        Table(ts, xs)
    ))
    else 
    push!(axis, @pgf PlotInc(
        {
            color = "black",
            mark = "none",
        },
        Table(ts, xs)
    ))
    end
end
    


for j in 1:20
    xs = [pred2[j,i] for i in 1:size(pred2,2)]
    if j ≠ 1
    push!(axis, @pgf PlotInc(
        {
            color = "blue",
            mark = "none",
            mark_repeat = 10,
            forget_plot = true,
        },
        Table(ts, xs)
    ))
    else
    push!(axis, @pgf PlotInc(
        {
            color = "blue",
            mark = "none",
            mark_repeat = 10,
        },
        Table(ts, xs)
    ))
    end
    end

    push!(axis, @pgf LegendEntry("\$X_2(t)\$ ground truth"))
    push!(axis, @pgf LegendEntry("\$X_2(t)\$ prediction"))

push!(tikzpicture, axis)
pgfsave("example3_plot_b.pgf", tikzpicture)
xs = [gt1[j,end] for j in 1:size(gt1,1)]
ys = [gt2[j,end] for j in 1:size(gt2,1)]

xpred = [pred1[j,end] for j in 1:size(pred1,1)]
ypred = [pred2[j,end] for j in 1:size(pred2,1)]
tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "\$X_1(T=10)\$",
        ylabel = "\$X_2(T=10)\$",
        width = "3in",
        height = "3in",
        # ymin=2,
        # ymax=9.9,
        enlarge_y_limits = 0.2,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(c)};"
        },
    },
    Plot({mark = "o", only_marks, color = "black"}, Table(xs, ys)),
    Plot({mark = "square", only_marks, color = "red"}, Table(xpred, ypred)),
    LegendEntry("ground truth"),
    LegendEntry("prediction"),
)

push!(tikzpicture, axis)
pgfsave("example3_plot_c.pgf", tikzpicture)