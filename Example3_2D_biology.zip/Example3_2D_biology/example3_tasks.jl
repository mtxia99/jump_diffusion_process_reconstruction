using Distributed
addprocs(1)
@everywhere using ProgressMeter
cor1s = [-1, -0.5, 0, 0.5, 1]
cor2s = [-1, -0.5, 0, 0.5, 1]
cors = [(cor1, cor2) for cor1 in cor1s for cor2 in cor2s]
# cor2 = 0, cor1-1,-0.5,0.5,1; cor1 = -1, cor2 = -1, -0.5; cor1 = -0.5, cor2=-1; cor1=0, cor2=-1,-0.5,0.5,1; cor1=-0.5,cor2=-1
# cors = [
#     [-1,0],
#     [-0.5,0],
#     [-0.5,-1],
#     [0.5,0],
#     [1,0],
#     [-1,-1],
#     [-1,-0.5],
#     [-0.5,-1],
#     [0,-1],
#     [0,-0.5],
#     [0,0.5],
#     [0,1],
# ]
σ1 = 0.1
σ2 = 0.1
noise_type = "langevin"
noise_type2 = "const"
repeats = 1:5

@everywhere function run_simulations(params)
    cor1, cor2, noise_type, noise_type2, repeat,σ1,σ2 = params
    cmd = `python example3_base.py --cor1=$cor1 --cor2=$cor2 --noise_type=$noise_type --noise_type2=$noise_type2 --repeat=$repeat --sigma1=$σ1 --sigma2=$σ2`
    run(pipeline(`$cmd`, stdout="log/$(cor1)_$(cor2)_$(noise_type)_$(σ1)_$(σ2)_$(repeat).log", stderr="log/$(cor1)_$(cor2)_$(noise_type)_$(σ1)_$(σ2)_$(repeat).err"))
end

params = [(cor1, cor2, noise_type, noise_type2, repeat, σ1, σ2) for (cor1, cor2) in cors, repeat in repeats]
progress_pmap(run_simulations, params; 
    progress = Progress(
    length(params); showspeed=true)
)
