using CSV, DataFrames
using PGFPlotsX
noise_type = "langevin"
noise_type2="const"
cor1s = [-1, -0.5, 0, 0.5, 1]
cor2s = [-1, -0.5, 0, 0.5, 1]
σ1 = 0.1
σ2 = 0.1
repeat_ids = 0:0
# "'data/example3_result'+ '_' + noise_type + '_' + noise_type2 + '_' + str(cor1) + '_' + str(cor2) + '_' + str(repeat) + '.csv"



function results_path(cor1, cor2, repeat_id, noise_type, noise_type2)
    result_path = "data/example3_no_prior_result_$(noise_type)_$(noise_type2)_$(cor1)_$(cor2)_$(σ1)_$(σ2)_$(repeat_id).csv"
    return result_path
end

result_df = DataFrame(
    f_error = [],
    s_error = [],
    h_error = [],
    cor1 = [],
    cor2 = [],
    repeat = [],
    noise_type = [],
    noise_type2 = [],
    sigma_para = [],
    sigma_para2 = []
)

for cor1 in cor1s, cor2 in cor2s, repeat_id in repeat_ids
    result_path = results_path(cor1, cor2, repeat_id, noise_type, noise_type2)
    if isfile(result_path)
        result_i = CSV.read(result_path, DataFrame)
        result_i.cor1 = [cor1]
        result_i.cor2 = [cor2]
        result_i.repeat = [repeat_id]
        result_i.noise_type = [noise_type]
        result_i.noise_type2 = [noise_type2]
        append!(result_df, result_i)
    end
end
CSV.write("example3_no_prior_result.csv", result_df)

using Statistics
# group by cor1 and cor2, and calculate the mean and std of f_error, s_error, h_error
group_df = groupby(result_df, [:cor1, :cor2])

# function to handle missing values
function skipmissing(x)
    return x[.!ismissing.(x)]
end

function mean_skipmissing(x)
    return mean(skipmissing(x))
end

function std_skipmissing(x)
    return std(skipmissing(x))
end

mean_df = combine(group_df, :f_error => mean_skipmissing, :s_error => mean_skipmissing, :h_error => mean_skipmissing)
# std_df = combine(group_df, :f_error => std, :s_error => std, :h_error => std)
# Row │ loss_type     loss_mean  loss_std   f_error_mean  f_error_std  s_error_mean  s_error_std  h_error_mean  h_error_std 
# │ String        Float64    Float64    Float64       Float64      Float64       Float64      Float64       Float64     
# ─────┼─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
# 1 │ mse            0.847071  0.0365444     0.0883808    0.039166       0.998116   0.00261816      0.978358    0.0193719
# 2 │ mean2_var      5.7317    0.715791      0.165236     0.110019       0.541958   0.408701        0.571974    0.386415
# 3 │ w2_decoupled   5.53387   0.886639      0.124865     0.0535461      0.289539   0.185003        0.285039    0.321729
# 4 │ w2_coupled    64.6946    2.47168       0.304583     0.0583607      0.964244   0.0397017       0.532491    0.0777483
# bar plot of errors, x symbolic coordinate: different loss types
# y: mean of errors, error bar: std of errors
using DataFrames, PGFPlotsX

# Assuming `result_df` DataFrame is already defined with your data

# Prepare the data for plotting
# This step is already completed based on your description

# Plotting
# Plot f_errors

tikzpicture = @pgf TikzPicture({"baseline"})
axis =@pgf Axis(
    {
        width = "2in",
        height = "2in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "cor1",
        ylabel = "cor2",
        # use colormap
        # colormap = "viridis",
        colorbar,
        yticklabel={},
        title="\\Large mean \$ \\sigma \$ error ",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        point_meta_min=0,
        point_meta_max=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{9}{9}\selectfont,fill=white] at (rel axis cs:.025,.975) {(a)};"
        },
        xmin = -1.25,
        xmax = 1.25,
        ymin = -1.25,
        ymax = 1.25,
    },
    Plot3({
        "matrix plot*",
        "mesh/rows" = length(cor1s),
        "mesh/cols" = length(cor2s),
    }, Table(
        mean_df.cor1,
        mean_df.cor2,
        mean_df.s_error_mean_skipmissing
    ))
    )
push!(tikzpicture, axis)

pgfsave("example3_no_prior_var_s_errors.tex", axis,include_preamble = true)
pgfsave("example3_no_prior_var_s_errors.pgf", axis,include_preamble = false)
# pgfsave("example3_no_prior_var_s_errors.pdf", axis,include_preamble = false)
# This code will create an Axis object which can be displayed in a Jupyter notebook
# or saved to a file using `pgfsave("myplot.tex", axis_object, include_preamble = true)`.
run(`tex2eps example3_no_prior_var_s_errors.tex`)

# Plot s_errors
tikzpicture = @pgf TikzPicture({"baseline"})
axis = @pgf Axis(
    {
        width = "2in",
        height = "2in",
        # ybar = "5pt",  # Distance between bars
        xlabel = "cor1",
        ylabel = "cor2",
        # use colormap
        # colormap = "viridis",
        colorbar,
        yticklabel={},
        title="\\Large mean \$ h \$ error",
        # heatmap plot, view from top
        view = "{0}{90}",
        # colorbar set width = 0.1in, move to left by 0.1in
        colorbar_style = {
            width = "0.1in",
            at = "{(1.05,1)}"
        },
        point_meta_min=0,
        point_meta_max=1,
        "after end axis/.code" = {
            raw"\node[anchor=north west, font=\fontsize{9}{9}\selectfont,fill=white] at (rel axis cs:.025,.975) {(b)};"
        },
        xmin = -1.25,
        xmax = 1.25,
        ymin = -1.25,
        ymax = 1.25,
        # invert y axis
    },
    Plot3({
        "matrix plot*",
        "mesh/rows" = length(cor1s),
        "mesh/cols" = length(cor2s),
    }, Table(
        mean_df.cor1,
        mean_df.cor2,
        mean_df.h_error_mean_skipmissing
    ))
    )
push!(tikzpicture, axis)

pgfsave("example3_no_prior_var_h_errors.tex", axis,include_preamble = true)
pgfsave("example3_no_prior_var_h_errors.pgf", axis,include_preamble = false)

run(`tex2eps example3_no_prior_var_h_errors.tex`)

