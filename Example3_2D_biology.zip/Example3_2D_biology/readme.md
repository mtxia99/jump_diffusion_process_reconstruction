# Example 3
## Dependency
The modified package of `torchsde` is located in `torchsde_master_homogeneous`.

Credit: Mingtao Xia

## Python scripts
- `example3_base.py` Training.

Credit: Mingtao Xia

## Julia scripts
Training task scheduling:
- `example3_task.jl` Set of tasks in the main text.

For plotting and analysis purposes. In terms of plotting, requires PGFPlotsX and external LaTeX installation that includes PGFPlots.
- `example3_plot.jl` Plotting the sample trajectories.
- `example3_analysis.jl` Loss and error plotting.
