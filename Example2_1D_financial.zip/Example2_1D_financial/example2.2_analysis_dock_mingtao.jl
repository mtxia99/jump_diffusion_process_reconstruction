# This code handles result from collaborater Mingtao
# The data format is very strange.
using DataFrames, CSV, Statistics, PGFPlotsX
σ1s = [0.05 + 0.05 * i for i in 0:2]
σ2s = [0.05 + 0.05 * i for i in 0:2]
noise_types = ["linear", "const", "langevin"]
params = [(σ1, σ2, noise_type) for σ1 in σ1s for σ2 in σ2s for noise_type in noise_types]
error_types = ["s_error", "h_error"]

function result_path(error_type, noise_type)
    return "data/shorttime1502f$(noise_type)$(noise_type)$(error_type)_.csv"
end
df = DataFrame(
    σ1 = Float64[],
    σ2 = Float64[],
    noise_type1 = String[],
    noise_type2 = String[],
    f_error = Float64[],
    σ_error = Float64[],
    h_error = Float64[]
)
data = CSV.read(result_path(error_types[2], noise_types[3]), DataFrame; header=false)

for noise_type in noise_types
    for i in 1:3, j in 1:3
        σ1 = σ1s[j]
        σ2 = σ2s[i]
        errors = [0.0]
        for error_type in error_types
            data = CSV.read(result_path(error_type, noise_type), DataFrame; header=false)
            push!(errors, data[i,j])
        end
        push!(df, (σ1, σ2, noise_type, noise_type, errors...))
    end
end
df

group_df = groupby(df, [:noise_type1, :noise_type2]) 
labels = ["(a)", "(b)", "(c)", "(d)", "(e)", "(f)", "(g)", "(h)", "(i)"]
# Plot s_errors
result_df = group_df[3]
i = 0
for result_df in group_df

    global i += 1
    tikzpicture = @pgf TikzPicture({"baseline"})
    axis = @pgf Axis(
        {
            width = "3in",
            height = "3in",
            # ybar = "5pt",  # Distance between bars
            xlabel = "\$ \\beta_0 \$",
            ylabel = "\$ \\sigma_0 \$",
            xtick = "{0.05,  0.1, 0.15}",
            xticklabels = "{0.05, 0.1, 0.15}",
            ytick = "{0.05, 0.1, 0.15}",
            yticklabels = "{0.05, 0.1, 0.15}",
            # use colormap
            # colormap = "viridis",
            colorbar,
            # yticklabel={},
            title="$(result_df.noise_type1[1])--$(result_df.noise_type2[1]) diffusion func. error ",
            # heatmap plot, view from top
            view = "{0}{90}",
            # colorbar set width = 0.1in, move to left by 0.1in
            colorbar_style = {
                width = "0.1in",
                at = "{(1.05,1)}"
            },
            point_meta_min=0,
            point_meta_max=1,
            xmin = 0.025,
            xmax = 0.175,
            ymin = 0.025,
            ymax = 0.175,
            # "after end axis/.code" = {
            #     raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(c)};"
            # },
            clip = "false",
        },
        Plot3({
            "matrix plot*",
            "mesh/rows" = length(σ1s),
            "mesh/cols" = length(σ2s),
        }, Table(
            result_df.σ1,
            result_df.σ2,
            result_df.σ_error
        )),
        "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.05,0.95) {$(labels[i])};"
        )
    push!(tikzpicture, axis)

    # pgfsave("example2.2_var_$(labels[i]).tex", axis,include_preamble = true)
    pgfsave("example2.2_var_$(labels[i]).pgf", axis,include_preamble = false)

    @show "saved to example2.2_var_$(labels[i]).pgf"
# run(`tex2eps example1_var_s_errors.tex`)
end

for result_df in group_df
    global i += 1
    tikzpicture = @pgf TikzPicture({"baseline"})
    axis = @pgf Axis(
        {
            width = "3in",
            height = "3in",
            # ybar = "5pt",  # Distance between bars
            xlabel = "\$ \\beta_0 \$",
            ylabel = "\$ \\sigma_0 \$",
            xtick = "{0.05,  0.1, 0.15}",
            xticklabels = "{0.05, 0.1, 0.15}",
            ytick = "{0.05, 0.1, 0.15}",
            yticklabels = "{0.05, 0.1, 0.15}",
            # use colormap
            # colormap = "viridis",
            colorbar,
            # yticklabel={},
            title="$(result_df.noise_type1[1])--$(result_df.noise_type2[1]), jump func. error",
            # heatmap plot, view from top
            view = "{0}{90}",
            # colorbar set width = 0.1in, move to left by 0.1in
            colorbar_style = {
                width = "0.1in",
                at = "{(1.05,1)}"
            },
            point_meta_min=0,
            point_meta_max=1,
            # "after end axis/.code" = {
            #     raw"\node[anchor=north west, font=\fontsize{12}{14}\selectfont] at (rel axis cs:.025,.975) {(c)};"
            # },
            clip = "false",
            xmin = 0.025,
            xmax = 0.175,
            ymin = 0.025,
            ymax = 0.175,
        },
        Plot3({
            "matrix plot*",
            "mesh/rows" = length(σ1s),
            "mesh/cols" = length(σ2s),
        }, Table(
            result_df.σ1,
            result_df.σ2,
            result_df.h_error
        )),
        "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.05,0.95) {$(labels[i])};"
        )
    push!(tikzpicture, axis)

    # pgfsave("example2.2_var_$(labels[i]).tex", axis,include_preamble = true)
    pgfsave("example2.2_var_$(labels[i]).pgf", axis,include_preamble = false)

    @show "saved to example2.2_var_$(labels[i]).pgf"
end
