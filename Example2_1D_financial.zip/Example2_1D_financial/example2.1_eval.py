import torch
import gc
import pandas as pd
import numpy as np
from torchsde_master_homogeneous.torchsde._core.sdeint import sdeint

torch.set_num_threads(1)

device = torch.device("cpu" if torch.cuda.is_available() else "cpu")

class TwoLayerNet(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        super(TwoLayerNet, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H)
        self.linear2 = torch.nn.Linear(H, H)
        self.linear3 = torch.nn.Linear(H, D_out)

    def forward(self, x):
        h_relu1 = self.linear1(x)
        h_relu1 = torch.relu(h_relu1)
        h_relu2 = self.linear2(h_relu1)
        h_relu2 = torch.relu(h_relu2)
        y_pred = self.linear3(h_relu2)
        return y_pred
batch_size, state_size, brownian_size, levy_size = 400, 1, 1, 1
H = 150
cor = 0
a = 0.05
class SDE(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'

    def __init__(self):
        super().__init__()
        self.mu = TwoLayerNet(state_size, H, 
                                    state_size)
        self.sigma = TwoLayerNet(state_size, H, 
                                    state_size * brownian_size) 
        self.jump = TwoLayerNet(state_size, H, 
                                    state_size * levy_size) 

    def f(self, t, y):
        f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
        for i in range(y.shape[0]):
            f_truth[i, 0] = a
            
        return f_truth 

    # Diffusion
    def g(self, t, y):
        t = t.expand(y.size(0), 1)
        ty = torch.cat([t, y], dim=1).to(device)
        sigma_matrix = self.sigma(y).view(batch_size, 
                                    state_size, 
                                    brownian_size)
        
        return sigma_matrix
    
    def h(self, t, y):
        jump_matrix = self.jump(y).view(batch_size, 
                                    state_size, 
                                    levy_size)
        return jump_matrix

# import sqrt
from math import sqrt

class SDE_truth(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'
    
    def __init__(self):
        super().__init__()


    # Drift
    def f(self, t, y):
        #print(y.shape)
        f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
        for i in range(y.shape[0]):
            f_truth[i, 0] = a
            
        return f_truth  # shape (batch_size, state_size)

    # Diffusion
    def g(self, t, y):
        g_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
        for i in range(y.shape[0]):
            if noise_type1 == 'const':
                
                g_truth[i, 0, 0] = noise_strength1 
            elif noise_type1 == 'linear':
                g_truth[i, 0, 0] = noise_strength1 * y[i, 0]
            elif noise_type1 == 'langevin':
                g_truth[i, 0, 0] = noise_strength1 * sqrt(abs(y[i, 0]))
            
            
        return g_truth #* sigma_para
    
    def h(self, t, y):
        h_truth = torch.zeros(y.shape[0], y.shape[1], levy_size).to(device)
        for i in range(y.shape[0]):
            if noise_type2 == 'const':
                h_truth[i, 0, 0] = noise_strength2 
            elif noise_type2 == 'linear':
                h_truth[i, 0, 0] = noise_strength2 * y[i, 0] 
            elif noise_type2 == 'langevin':
                h_truth[i, 0, 0] = noise_strength2 * sqrt(abs(y[i, 0]))
            
        return h_truth#* sigma_para / 2 


# Define spatial grid
spatial_grid = np.linspace(0.5, 1.5, 400)  # Example spatial grid from -1 to 1
spatial_grid = torch.tensor(spatial_grid, dtype=torch.float32).unsqueeze(1).to(device)
noise_type1 = "langevin"  # Replace with actual input value
noise_type2 = "langevin"  # Replace with actual input value
noise_strength1 = 0.1  # Replace with actual input value
noise_strength2 = 0.1  # Replace with actual input value
g_values_list = []
h_values_list = []
repeats = range(5)
import os

for repeat in repeats:
    # Path to the model
    model_path = f'data/example2_fprior_{noise_type1}{noise_type2}{noise_strength1}_{noise_strength2}_{cor}_{repeat}.pkl'

    # check if model exists
    if not os.path.exists(model_path):
        raise ValueError(f"Model {model_path} does not exist. Please train the model first.")

    # Initialize the model and load the trained parameters
    model = SDE().to(device)
    model.load_state_dict(torch.load(model_path))
    model.eval()

    # Evaluate g and h at t=0 over the spatial grid
    t = torch.tensor([0.0], dtype=torch.float32).to(device)
    g_values = model.g(t, spatial_grid)
    h_values = model.h(t, spatial_grid)

    # Convert to numpy for easier handling and save as DataFrame
    g_values_np = g_values.detach().cpu().numpy()
    # for g values make them all positive
    g_values_np = np.abs(g_values_np)
    h_values_np = h_values.detach().cpu().numpy()

    g_values_list.append(g_values_np.squeeze())
    h_values_list.append(h_values_np.squeeze())

# compute mean and variance of g and h values at each spatial point
g_values_np = np.stack(g_values_list)
h_values_np = np.stack(h_values_list)

g_values_mean = np.mean(g_values_np, axis=0)
g_values_std = np.std(g_values_np, axis=0)

h_values_mean = np.mean(h_values_np, axis=0)
h_values_std = np.std(h_values_np, axis=0)
# convert to dataframe for both g and h, mean and std
g_df = pd.DataFrame(g_values_mean, columns=['g'])
g_df['g_std'] = g_values_std
h_df = pd.DataFrame(h_values_mean, columns=['h'])
h_df['h_std'] = h_values_std



# add xs to each dataframe
g_df['x'] = spatial_grid.cpu().numpy()
h_df['x'] = spatial_grid.cpu().numpy()

g_df.to_csv('g_values_at_t0.csv', index=False)
h_df.to_csv('h_values_at_t0.csv', index=False)



ground_truth = SDE_truth().to(device)

g_values_truth = ground_truth.g(t, spatial_grid)

h_values_truth = ground_truth.h(t, spatial_grid)

g_values_truth_np = g_values_truth.detach().cpu().numpy()

g_values_truth_np = np.abs(g_values_truth_np)

h_values_truth_np = h_values_truth.detach().cpu().numpy()

g_df_truth = pd.DataFrame(g_values_truth_np.squeeze(), columns=['g'])

h_df_truth = pd.DataFrame(h_values_truth_np.squeeze(), columns=['h'])

g_df_truth['x'] = spatial_grid.cpu().numpy()

h_df_truth['x'] = spatial_grid.cpu().numpy()

g_df_truth.to_csv('g_values_at_t0_truth.csv', index=False)

h_df_truth.to_csv('h_values_at_t0_truth.csv', index=False)

print("Evaluation complete. Results saved to 'g_values_at_t0.csv' and 'h_values_at_t0.csv'")


