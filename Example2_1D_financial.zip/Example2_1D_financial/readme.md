# Example 2
## Dependency
The modified package of `torchsde` is located in `torchsde_master_homogeneous`.

Credit: Mingtao Xia

## Python scripts
- `example2_base.py` Training with no prior knowledge.
- `example2_base_fprior.py` Training with prior knowledge of the drift function $f$.
- `example2_base_gprior.py` Training with prior knowledge of the diffusion function $g$.
- `example2_base_hprior.py` Training with prior knowledge of the jump function $h$.

Credit: Mingtao Xia

## Julia scripts
Training task scheduling:
- `example2.1_task.jl` Set of tasks in the main text.
- `example2.2_task.jl` Set of tasks in the supplementary material.

For plotting and analysis purposes. In terms of plotting, requires PGFPlotsX and external LaTeX installation that includes PGFPlots.
- `example2.1_plot.jl` Plotting the sample trajectories.
- `example2.1_analysis.jl` Loss and error plotting.
- `example2.2_analysis.jl` Loss and error plotting for the supplementary material.