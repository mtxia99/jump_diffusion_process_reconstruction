using CSV, DataFrames
using PGFPlotsX

noise1_types = ["const","linear","langevin"]
noise2_types = ["const","linear","langevin"]
error_types = ["f_error","s_error","h_error"]
prior_types = ["noprior", "fprior", "sigmaprior", "hprior"]

noise_strength1 = 0.1
noise_strength2 = 0.1

file_path(prior_type, noise1_type, noise2_type) = "data/example2_$(prior_type)_result_$(noise1_type)$(noise2_type)$(noise_strength1)$(noise_strength2).csv"

df = DataFrame(
    noise1_type = String[],
    noise2_type = String[],
    error_type = String[],
    prior_type = String[],
    value = Float64[]
)

# test
noise1_type = "const"
noise2_type = "const"
error_type = "f_error"
prior_type = "noprior"
file = file_path(prior_type, noise1_type, noise2_type)
isfile(file)
data = CSV.read(file, DataFrame)
# 5×3 DataFrame
#  Row │ f_error   sigma_error  h_error  
#      │ Float64   Float64      Float64  
# ─────┼─────────────────────────────────
#    1 │ 0.528624    0.0969544  0.22135
#    2 │ 5.01852     2.54632    0.287728
#    3 │ 1.2916      0.800896   0.339621
#    4 │ 0.78839     0.549046   0.351464
#    5 │ 1.53498     0.846447   0.273107

using Statistics
for noise1_type in noise1_types, noise2_type in noise2_types, prior_type in prior_types
    file = file_path(prior_type, noise1_type, noise2_type)
    # if isfile(file)
        data = CSV.read(file, DataFrame)
        for row in eachrow(data)
            push!(df, (noise1_type, noise2_type, "f_error", prior_type, row.f_error))
            push!(df, (noise1_type, noise2_type, "sigma_error", prior_type, row.sigma_error))
            push!(df, (noise1_type, noise2_type, "h_error", prior_type, row.h_error))
        end
    # else
    #     @warn "File not found: $(file)"
    # end
end
df
grouped_df = groupby(df, [:error_type, :prior_type,])
df_mean = combine(grouped_df, [:value => mean, :value => std])
# sort by prior type
df_mean = sort(df_mean, :prior_type)

CSV.write("example2_analysis1_mean_errors.csv", df_mean)

grouped_df = groupby(df, [:error_type, :prior_type, :noise1_type, :noise2_type])
# find the mean of the value column
using Statistics
df_mean = combine(grouped_df, [:value => mean, :value => std])
# sort by prior type
df_mean = sort(df_mean, :prior_type)

# CSV.write("example2_analysis1_mean_errors.csv", df_mean)

grouped_df = groupby(df_mean, [:noise1_type, :noise2_type])
sub_df = grouped_df[1]
labels = ["(d)", "(e)", "(f)", "(g)", "(h)", "(i)", "(j)", "(k)", "(l)", "(m)", "(n)", "(o)", "(p)", "(q)", "(r)"]
for (i,sub_df) in enumerate(grouped_df)
sub_f_error = sub_df[sub_df.error_type .== "f_error", :]
sub_s_error = sub_df[sub_df.error_type .== "sigma_error", :]
sub_h_error = sub_df[sub_df.error_type .== "h_error", :]
tikzpicture = @pgf TikzPicture({"baseline"})
if i ≥ 7
axis =@pgf Axis(
    {
        ybar,
        width = "2.4in",
        height = "2.4in",
        # ybar = "5pt",  # Distance between bars
        title="$(sub_df.noise1_type[1])-$(sub_df.noise2_type[1]) noise",
        bar_width = "5pt",
        enlarge_x_limits = 0.2,
        legend_style = {at = "{(0.5, 0.96)}", anchor = "north", legend_columns = -1, fill="none", draw="none"},
        ylabel = "error",
        xlabel = "prior type",
        symbolic_x_coords = prior_types,
        # symbolic_x_coords = pretty_loss_types,
        xtick = "data",
        xticklabel_style = {rotate = 45, anchor = "east"},
        xticklabels = ["drift prior", "jump prior", "no prior", "diffusion prior"],
        # nodes_near_coords_align = {"vertical"},
        # nodes_near_coords,
        # clip=false,
        ymin = 0,  # Adjust based on your data
        ymax=2,
    # "after end axis/.code" = {
    #     "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:.02,.98) {$(labels[i])};"
    # },
    },
    PlotInc(
        {fill = "blue",
        draw = "blue",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_f_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_f_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_f_error.value_std],
        ]),
    ),
    PlotInc(
        {fill = "red",
        draw="red",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_s_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_s_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_s_error.value_std],
        ]),
    ),
    PlotInc(
        {fill = "green",
        draw = "green",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_h_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_h_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_h_error.value_std],
        ]),
    ),
    "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.02,0.98) {$(labels[i])};"

)
else
    axis =@pgf Axis(
    {
        ybar,
        width = "2.4in",
        height = "2.4in",
        # ybar = "5pt",  # Distance between bars
        title="$(sub_df.noise1_type[1])-$(sub_df.noise2_type[1]) noise",
        bar_width = "5pt",
        enlarge_x_limits = 0.2,
        legend_style = {at = "{(0.5, 0.96)}", anchor = "north", legend_columns = 1, fill="none", draw="none"},
        ylabel = "error",
        # xlabel = "prior type",
        symbolic_x_coords = prior_types,
        legend_cell_align = "left",
        # symbolic_x_coords = pretty_loss_types,
        xtick = "data",
        # hide x tick label 
        xticklabels = {""},
        # xticklabel_style = {rotate = 45, anchor = "east"},
        # nodes_near_coords_align = {"vertical"},
        # nodes_near_coords,
        # clip=false,
        ymin = 0,  # Adjust based on your data
        ymax=2,
    # "after end axis/.code" = {
    #     "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:.02,.98) {$(labels[i])};"
    # },
    },
    PlotInc(
        {fill = "blue",
        draw = "blue",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_f_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_f_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_f_error.value_std],
        ]),
    ),
    PlotInc(
        {fill = "red",
        draw = "red",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_s_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_s_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_s_error.value_std],
        ]),
    ),
    PlotInc(
        {fill = "green",
        draw = "green",
        # plot std,
        "error bars/.cd",
        "y dir=both",
        "y explicit" 
        },
         Table({
            "x = x",
            "y = y",
            "y error = y_error",
         },[
            "x" => sub_h_error.prior_type,
            "y" => [minimum([v,4]) for v in sub_h_error.value_mean],
            "y_error" => [minimum([v,4]) for v in sub_h_error.value_std],
        ]),
    ),
    "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.02,0.98) {$(labels[i])};"
)
end
if i == 1
    push!(axis,    @pgf Legend("\\small drift error", "\\small diffusion error", "\\small jump error"))
end
push!(tikzpicture, axis)
pgfsave("example2_analysis1_errors_$(labels[i]).pgf", tikzpicture, include_preamble = false)
pgfsave("example2_analysis1_errors_$(labels[i]).tex", tikzpicture, include_preamble = true)
end

