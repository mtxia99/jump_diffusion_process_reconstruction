using CSV, DataFrames
using PGFPlotsX

noise1_types = ["langevin"]
noise2_types = ["langevin"]
error_types = ["f_error","s_error","h_error"]
prior_types = ["noprior", "fprior", "sigmaprior", "hprior"]
sample_sizes = [100,200,400,800]
noise_strength1 = 0.1
noise_strength2 = 0.1

file_path(prior_type, noise1_type, noise2_type,sample_size) = "data/example2_$(prior_type)_result_$(noise1_type)$(noise2_type)$(noise_strength1)$(noise_strength2)_sample_size_$(sample_size).csv"

df = DataFrame(
    noise1_type = String[],
    noise2_type = String[],
    sample_size = Int[],
    error_type = String[],
    prior_type = String[],
    value = Float64[]
)

# test
noise1_type = "langevin"
noise2_type = "langevin"
error_type = "f_error"
prior_type = "noprior"
file = file_path(prior_type, noise1_type, noise2_type,100)
isfile(file)
data = CSV.read(file, DataFrame)
# 5×3 DataFrame
#  Row │ f_error   sigma_error  h_error  
#      │ Float64   Float64      Float64  
# ─────┼─────────────────────────────────
#    1 │ 0.528624    0.0969544  0.22135
#    2 │ 5.01852     2.54632    0.287728
#    3 │ 1.2916      0.800896   0.339621
#    4 │ 0.78839     0.549046   0.351464
#    5 │ 1.53498     0.846447   0.273107

using Statistics
for noise1_type in noise1_types, noise2_type in noise2_types, prior_type in prior_types, sample_size in sample_sizes
    file = file_path(prior_type, noise1_type, noise2_type, sample_size)
    # if isfile(file)
        data = CSV.read(file, DataFrame)
        for row in eachrow(data)
            push!(df, (noise1_type, noise2_type, sample_size, "f_error", prior_type, row.f_error))
            push!(df, (noise1_type, noise2_type, sample_size, "sigma_error", prior_type, row.sigma_error))
            push!(df, (noise1_type, noise2_type, sample_size, "h_error", prior_type, row.h_error))
        end
    # else
    #     @warn "File not found: $(file)"
    # end
end
df
grouped_df = groupby(df, [:error_type, :prior_type, :sample_size])
df_mean = combine(grouped_df, [:value => mean, :value => std])
# sort by prior type
df_mean = sort(df_mean, [:prior_type, :error_type, :sample_size])

CSV.write("example2_analysis3_mean_errors.csv", df_mean)

grouped_df = groupby(df, [:error_type, :prior_type, :noise1_type, :noise2_type,:sample_size])
# find the mean of the value column
using Statistics
df_mean = combine(grouped_df, [:value => mean, :value => std])
# sort by prior type
df_mean = sort(df_mean, :prior_type)

# CSV.write("example2_analysis1_mean_errors.csv", df_mean)

using PGFPlotsX
# delete 800 sample size from the data
df_mean = filter(row -> row.sample_size != 800, df_mean)
function legendname(prior_type)
    if prior_type == "noprior"
        return "no prior"
    elseif prior_type == "fprior"
        return "drift prior"
    elseif prior_type == "sigmaprior"
        return "diffusion prior"
    elseif prior_type == "hprior"
        return "jump prior"
    end
end
marker_styles = ["*", "triangle*", "square*", "diamond*"]

f_error_df = filter(row -> row.error_type == "f_error", df_mean)
f_error_tikz = @pgf TikzPicture({baseline})
f_error_axis = @pgf Axis(
    {
        width="3in",
        height="3in",
        title = "drift error",
        xlabel = "sample size \$ M_s\$",
        ylabel = "error",
        ymin=0,
        xmode="log",
        xtick="{100,200,400,800}",
        xticklabels="{100,200,400,800}",
        legend_style="at={(0.97,0.97)},anchor={north east},draw=none",
        # ymax=1,
    }  
)
for (prior_type, marker) in zip(prior_types, marker_styles)
    f_error_data = filter(row -> row.prior_type == prior_type, f_error_df)
    f_error_plot = @pgf PlotInc( {mark=marker,thick,"error bars/.cd", "y dir "= "both", "y explicit"},
        Table({
            "x=sample_size",
            "y=mean",
            "y error=std",
        }, [
            "sample_size" => f_error_data.sample_size,
            "mean" => f_error_data.value_mean,
            "std" => f_error_data.value_std,
        ])
    )
    legend = @pgf LegendEntry(legendname(prior_type))
    push!(f_error_axis, f_error_plot)
    push!(f_error_axis, legend)
end
# add node (a) to the plot
push!(f_error_axis, @pgf {raw"\node at (rel axis cs:0,1) [anchor=north west] {(a)};"} )
push!(f_error_tikz, f_error_axis)
pgfsave("example2_analysis3_f_error.tex", f_error_tikz)
pgfsave("example2_analysis3_f_error.pdf", f_error_tikz)

# sigma error
s_error_df = filter(row -> row.error_type == "sigma_error", df_mean)
s_error_tikz = @pgf TikzPicture({baseline})
s_error_axis = @pgf Axis(
    {
        width="3in",
        height="3in",
        title = "diffusion error",
        xlabel = "sample size \$ M_s\$",
        ylabel = "error",
        ymin=0,
        xmode="log",
        xtick="{100,200,400,800}",
        xticklabels="{100,200,400,800}",
        legend_style="at={(0.97,0.97)},anchor={north east},draw=none",
        # ymax=1,
    }  
)
for (prior_type, marker) in zip(prior_types, marker_styles)
    s_error_data = filter(row -> row.prior_type == prior_type, s_error_df)
    s_error_plot = @pgf PlotInc( {mark=marker,thick,"error bars/.cd", "y dir "= "both", "y explicit"},
        Table({
            "x=sample_size",
            "y=mean",
            "y error=std",
        }, [
            "sample_size" => s_error_data.sample_size,
            "mean" => s_error_data.value_mean,
            "std" => s_error_data.value_std,
        ])
    )
    legend = @pgf LegendEntry(legendname(prior_type))
    push!(s_error_axis, s_error_plot)
    push!(s_error_axis, legend)
end
# add node (b) to the plot
push!(s_error_axis, @pgf {raw"\node at (rel axis cs:0,1) [anchor=north west] {(b)};"} )
push!(s_error_tikz, s_error_axis)
pgfsave("example2_analysis3_sigma_error.tex", s_error_tikz)
pgfsave("example2_analysis3_sigma_error.pdf", s_error_tikz)

# h error
h_error_df = filter(row -> row.error_type == "h_error", df_mean)
h_error_tikz = @pgf TikzPicture({baseline})
h_error_axis = @pgf Axis(
    {
        width="3in",
        height="3in",
        title = "jump error",
        xlabel = "sample size \$ M_s\$",
        ylabel = "error",
        ymin=0,
        xmode="log",
        xtick="{100,200,400,800}",
        xticklabels="{100,200,400,800}",
        legend_style="at={(0.97,0.97)},anchor={north east},draw=none",
        # ymax=1,
    }  
)
for (prior_type, marker) in zip(prior_types, marker_styles)
    h_error_data = filter(row -> row.prior_type == prior_type, h_error_df)
    h_error_plot = @pgf PlotInc( {mark=marker,thick,"error bars/.cd", "y dir "= "both", "y explicit"},
        Table({
            "x=sample_size",
            "y=mean",
            "y error=std",
        }, [
            "sample_size" => h_error_data.sample_size,
            "mean" => h_error_data.value_mean,
            "std" => h_error_data.value_std,
        ])
    )
    legend = @pgf LegendEntry(legendname(prior_type))
    push!(h_error_axis, h_error_plot)
    push!(h_error_axis, legend)
end
# add node (c) to the plot
push!(h_error_axis, @pgf {raw"\node at (rel axis cs:0,1) [anchor=north west] {(c)};"} )
push!(h_error_tikz, h_error_axis)
pgfsave("example2_analysis3_h_error.tex", h_error_tikz)
pgfsave("example2_analysis3_h_error.pdf", h_error_tikz)
