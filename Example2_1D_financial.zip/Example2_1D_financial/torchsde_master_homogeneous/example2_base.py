# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 18:59:32 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Dec 28 15:51:44 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 23:14:10 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 10:35:17 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 23:27:26 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Nov  4 22:32:02 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Nov  4 21:15:22 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Nov  4 12:31:48 2023

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Nov  4 00:35:03 2023

@author: 12147
"""

# -*- coding: utf-8 -*-




import torch

torch.set_num_threads(1)
from torchsde_master_homogeneous import *
from torchsde_master_homogeneous.torchsde._core.sdeint import *
import pandas as pd
import random
import time
import csv
from tqdm import tqdm
from math import sqrt
import pdb
import argparse

device = torch.device("cpu" if torch.cuda.is_available() else "cpu")
parser = argparse.ArgumentParser(description='jump SDE')
parser.add_argument('--noise_type1', default='const', type=str, help='type of diffusion noise: const, linear, langevin',  required=False)
parser.add_argument('--noise_type2', default='const', type=str, help='type of jump noise: const, linear, langevin',  required=False)
parser.add_argument('--loss', default='w2_decoupled', type=str, help='type of loss', required=False)
parser.add_argument('--repeat', default=2, type=int, help='repeat number', required=False)
parser.add_argument('--start_noise1', default=0.025, type=float, help='diffusion noise start', required=False)
parser.add_argument('--start_noise2', default=0.025, type=float, help='jump noise start', required=False)
parser.add_argument('--noise1_step', default=0.025, type=float, help='diffusion noise step', required=False)
parser.add_argument('--noise2_step', default=0.025, type=float, help='jump noise step', required=False)
parser.add_argument('--noise1_num', default=3, type=int, help='diffusion noise mesh number', required=False)
parser.add_argument('--noise2_num', default=3, type=int, help='jump noise mesh number', required=False)


# parse arguments
args = parser.parse_args()
noise_type1 = args.noise_type1
noise_type2 = args.noise_type2
loss_type = args.loss
repeat_number = args.repeat
start_noise1 = args.start_noise1
start_noise2 = args.start_noise2
noise1_step = args.noise1_step
noise2_step = args.noise2_step
noise1_num = args.noise1_num
noise2_num = args.noise2_num

    
    
def sde_run(a, sigma_para2, sigma_para, noise, noise2):
    global repear_number
    noise_type = noise
    noise_2 = noise2 
    batch_size, state_size, brownian_size, levy_size = 200, 1, 1, 1
    H = 150
    t_size = 101
    print(device)
    class TwoLayerNet(torch.nn.Module):
        def __init__(self, D_in, H, D_out):
            """
            In the constructor we instantiate two nn.Linear modules and assign them as
            member variables.
            """
            super(TwoLayerNet, self).__init__()
            self.linear1 = torch.nn.Linear(D_in, H)
            self.linear2 = torch.nn.Linear(H, H)
            self.linear3 = torch.nn.Linear(H, D_out)
            
            #return data
        
        def forward(self, x):
            """
            In the forward function we accept a Tensor of input data and we must return
            a Tensor of output data. We can use Modules defined in the constructor as
            well as arbitrary operators on Tensors.
            """
            h_relu1 = self.linear1(x)
            h_relu1 = torch.relu(h_relu1)
            h_relu2 = self.linear2(h_relu1)
            h_relu2 = torch.relu(h_relu2)
            y_pred = self.linear3(h_relu2)
            return y_pred
    
    params = [0.1, 0.21]
    #params = [0, 1]
    
        
    
    b = 5
    sigma = 0.4#0.5
    v = 0.1
    from math import sqrt
    print('start')
    #
    # for each sigma = 0.02:0.02:0.18, each cor=-1:-.25:1
    # for each noise type const, linear, langevin
    # repeat 10 experiments, a total of 810 models 
    #sigma_para = 0.1#0.2#0.1:0.05:0.5#0.2
    #sigma_para2 = 0.1#0.3#0.3#0.4#0.3
    #a = -0.1#0.05 -  sigma_para**2 / 2 - sigma_para2**2 / 2#0.15 -  sigma_para**2 / 2 - sigma_para2**2 / 2
    cor = 0 #-1:-.25:1
    if cor == 0:
        x = 1
    else:
        x = (2 - sqrt(4 - 4 * cor**2)) / 2 / cor
        
    Sigma = [[0.1, -0.05], [-0.05, 0.05]]
    #noise_type = 'const'
    #noise_type = 'linear'
    #noise_type = 'langevin'
    
    class SDE(torch.nn.Module):
        noise_type = 'general'
        sde_type = 'ito'
    
        def __init__(self):
            super().__init__()
            self.mu = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size)
            self.sigma = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size * brownian_size)#torch.nn.Linear(state_size, 
                                         #state_size * brownian_size)
            self.jump = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                      state_size * levy_size)#torch.nn.Linear(state_size, 
                                         #state_size * brownian_size)
    
        # Drift
        def f(self, t, y):
            t = t.expand(y.size(0), 1)
            ty = torch.cat([t, y], dim=1).to(device)

            #f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
            #for i in range(y.shape[0]):
            #    f_truth[i, 0] = -params[0]*y[i, 0] - params[1]*y[i, 1]# - y[i, 1]
            #    f_truth[i, 1] = params[1]*y[i, 0] - params[0]*y[i, 1]#y[i, 0]
                
            return self.mu(y)  # shape (batch_size, state_size)
    
        # Diffusion
        def g(self, t, y):
            t = t.expand(y.size(0), 1)
            ty = torch.cat([t, y], dim=1).to(device)
            sigma_matrix = self.sigma(y).view(batch_size, 
                                      state_size, 
                                      brownian_size)
            
            #sigma_result = torch.zeros(batch_size, state_size, brownian_size)
            #sigma_result[:, 0, 0] = sigma_matrix[:, 0, 0]
            #sigma_result[:, 0, 1] = sigma_matrix[:, 1, 1] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 0] = -sigma_matrix[:, 0, 0] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 1] = sigma_matrix[:, 1, 1]
            #print(sigma_result[1, :, :])
            #pdb.set_trace()
            #for i in range(y.shape[0]):
            #    sigma_matrix[i, 0, 1] = 0
            #    sigma_matrix[i, 1, 0] = 0
            return sigma_matrix#self.sigma(y).view(batch_size, 
                                #      state_size, 
                                 #     brownian_size)
        
        #def h(self, t, y):
        ##    global noise_type
            #h_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
            #for i in range(y.shape[0]):
            #    if noise_type == 'const':
            #        
            #        h_truth[i, 0, 0] = sigma_para #sqrt(abs(params[0]*y[i, 0])) #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
            #    elif noise_type == 'linear':
            #        h_truth[i, 0, 0] = sigma_para * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x * abs(y[i, 0])
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para * y[i, 1]
            #    elif noise_type == 'langevin':
            #        h_truth[i, 0, 0] = sigma_para * sqrt(abs(y[i, 0])) #* sqrt(t+1)
            #        h_truth[i, 0, 1] = sigma_para * x * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
            #        h_truth[i, 1, 0] = sigma_para * x * sqrt(abs(y[i, 0]))
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
            #        h_truth[i, 1, 1] = sigma_para * x * sqrt(abs(y[i, 1]))
                
                
            #return h_truth * sigma_para * 0 / 5
        
        def h(self, t, y):
        #    t = t.expand(y.size(0), 1)
        #    ty = torch.cat([t, y], dim=1).to(device)
            jump_matrix = self.jump(y).view(batch_size, 
                                      state_size, 
                                      levy_size)
            
            #sigma_result = torch.zeros(batch_size, state_size, brownian_size)
            #sigma_result[:, 0, 0] = sigma_matrix[:, 0, 0]
            #sigma_result[:, 0, 1] = sigma_matrix[:, 1, 1] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 0] = -sigma_matrix[:, 0, 0] * sqrt(abs(params[1] / params[0]))
            #sigma_result[:, 1, 1] = sigma_matrix[:, 1, 1]
            #print(sigma_result[1, :, :])
            #pdb.set_trace()
            #for i in range(y.shape[0]):
            #    sigma_matrix[i, 0, 1] = 0
            #    sigma_matrix[i, 1, 0] = 0
            return jump_matrix#self.sigma(y).view(batch_size, 
        
        
    class SDE_truth(torch.nn.Module):
        noise_type = 'general'
        sde_type = 'ito'
        
        def __init__(self):
            super().__init__()
    
    
        # Drift
        def f(self, t, y):
            #print(y.shape)
            f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
            for i in range(y.shape[0]):
                f_truth[i, 0] = a#params[0]#5 - params[0]*y[i, 0]
                
            return f_truth  # shape (batch_size, state_size)
    
        # Diffusion
        def g(self, t, y):
            nonlocal noise_type, noise_2
            g_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
            for i in range(y.shape[0]):
                if noise_type == 'const':
                    
                    g_truth[i, 0, 0] = sigma_para2 #sqrt(abs(params[0]*y[i, 0])) #* sqrt(t+1)
                    #g_truth[i, 0, 1] = sigma_para * x#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #g_truth[i, 1, 0] = sigma_para * x
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #g_truth[i, 1, 1] = sigma_para #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
                elif noise_type == 'linear':
                    g_truth[i, 0, 0] = sigma_para2 * y[i, 0] #* sqrt(abs(y[i, 0]))#y[i, 0] #* sqrt(t+1)
                    #g_truth[i, 0, 1] = sigma_para * x * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #g_truth[i, 1, 0] = sigma_para * x * abs(y[i, 0])
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #g_truth[i, 1, 1] = sigma_para * y[i, 1]
                elif noise_type == 'langevin':
                    g_truth[i, 0, 0] = sigma_para2 * sqrt(abs(y[i, 0])) #* sqrt(t+1)
                    #g_truth[i, 0, 1] = sigma_para * x * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #g_truth[i, 1, 0] = sigma_para * x * sqrt(abs(y[i, 0]))
                    ##g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #g_truth[i, 1, 1] = sigma_para * sqrt(abs(y[i, 1]))
                
                
            return g_truth #* sigma_para
        
        def h(self, t, y):
            nonlocal noise_type, noise_2
            h_truth = torch.zeros(y.shape[0], y.shape[1], levy_size).to(device)
            for i in range(y.shape[0]):
                if noise_2 == 'const':
                    
                    h_truth[i, 0, 0] = sigma_para #sqrt(abs(params[0]*y[i, 0])) #* sqrt(t+1)
                    #h_truth[i, 0, 1] = sigma_para * x#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #h_truth[i, 1, 0] = sigma_para * x
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #h_truth[i, 1, 1] = sigma_para #sqrt(abs(params[0]*y[i, 1]))#Sigma[1][1] * y[i, 1]
                elif noise_2 == 'linear':
                    h_truth[i, 0, 0] = sigma_para * y[i, 0] # sigma_para #* sqrt(t+1)
                    #h_truth[i, 0, 1] = sigma_para * x * abs(y[i, 1])#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #h_truth[i, 1, 0] = sigma_para * x * abs(y[i, 0])
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #h_truth[i, 1, 1] = sigma_para * y[i, 1]
                elif noise_2 == 'langevin':
                    h_truth[i, 0, 0] = sigma_para * sqrt(abs(y[i, 0])) #* sqrt(t+1)
                    #h_truth[i, 0, 1] = sigma_para * x * sqrt(abs(y[i, 1]))#sqrt(abs(params[1]*y[i, 1]))#Sigma[0][1] * y[i, 1]
                    #h_truth[i, 1, 0] = sigma_para * x * sqrt(abs(y[i, 0]))
                    #g_truth[i, 1, 0] = -sqrt(abs(params[1]*y[i, 0]))#Sigma[1][0] * y[i, 0] #* sqrt(t+1)
                    #h_truth[i, 1, 1] = sigma_para * sqrt(abs(y[i, 1]))
                
                
            return h_truth#* sigma_para / 2 
    
    error_f_list = []
    error_s_list = []
    error_h_list = []
    for repeat in range(repeat_number):
        sde = SDE().to(device)
        sde_truth = SDE_truth().to(device)
        y0 = torch.zeros(batch_size, state_size).to(device)
        for i in range(batch_size):
            if i < 100:
                y0[i, 0] = 1#1#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
                #y0[i, 1] = 1
            else:
                y0[i, 0] = 1#1#0.5 #+ float(torch.randn(1)[0] *0.5)
                #y0[i, 1] = 1
                
            if y0[i, 0] < 0:
                print("error")
                
        t_end = 20#10
        ts = torch.linspace(0, t_end, t_size).to(device)
        
        ys_truth = sdeint(sde_truth, y0, ts).to(device)
        print('start')
        truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
        truth_data.to_csv('drift_prior_ground_truth_cir1_damped2cuda' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        #truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
        #truth_data.to_csv('ground_truth_cir2_damped2cuda' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        #print(sde.parameters())
        #pdb.set_trace()
        criterion = torch.nn.MSELoss(reduction='sum')
        optimizer = torch.optim.Adam(sde.parameters(), lr=0.002,betas= (0.9, 0.999), weight_decay=0.005)
        epoch = 500
        loss_list = []
        ttime = time.time()
        g_error_list = []
        sigma_error_list = []
        
        
                
        from math import pi    
        
               
        import ot     
        def distance(P, Q):
            cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
            return cost_matrix
        
        def w2_decoupled(y, y_pred):
            batch_size = y.shape[1]
            state_size = y.shape[2]
            t_size = y.shape[0]
            loss = 0
            for i in range(1, t_size):
                weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
        
                loss += ot.emd2(weights, weights, distance(y[i, :, :], y_pred[i, :, :]))
            
            return loss
        
        def w2_coupled(y, y_pred):
            batch_size = y.shape[1]
            state_size = y.shape[2]
            t_size = y.shape[0]
            loss = 0
            y_coupled = torch.zeros(batch_size, state_size * t_size)
            y_pred_coupled = torch.zeros(batch_size, state_size * t_size)
            for i in range(0, t_size):
                y_coupled[:, i*state_size:(i+1)*state_size] += y[i, :, :]
                y_pred_coupled[:, i*state_size:(i+1)*state_size] += y_pred[i, :, :]
            
            weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
        
            loss += ot.emd2(weights, weights, distance(y_coupled[:, :], y_pred_coupled[:, :]))
            
            return loss
        
        import pdb
    
    
        error_f = []
        error_s = []
        error_h = []
        def total_error1(sde_truth, sde, i0):
            
            summ = 0
            summ_ref = 0
            
            for i in range(t_size):
                summ += torch.sum(torch.abs( sde.f(ts[i], ys[i]) - sde_truth.f(ts[i], ys[i])))
                summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys[i])))# + torch.sum(torch.abs(sde.f(ts[i], ys_truth[i])))
                        
            summ1 = 0
            summ1_ref = 0
            for i in range(t_size):
                s1 = sde_truth.g(ts[i], ys[i])
                s2 = sde.g(ts[i], ys[i])
                #if i0 > 50:
                #    print(s1, s2)
                    #pdb.set_trace()
                    
                for j in range(ys.shape[1]):
                    summ1_ref += torch.sum(torch.abs(s1[j])) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
                    summ1 += torch.sum(torch.abs(torch.abs(s1[j]) - torch.abs(s2[j])))
                    #summ1_ref += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)))) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
                    #summ1 += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1)) - torch.matmul(s2[j], s2[j].transpose(0, 1))))
            
            summ2 = 0
            summ2_ref = 0
            for i in range(t_size):
                h1 = sde_truth.h(ts[i], ys[i])
                h2 = sde.h(ts[i], ys[i])
                #if i0 > 50:
                #    print(s1, s2)
                    #pdb.set_trace()
                    
                for j in range(ys.shape[1]):
                    summ2_ref += torch.sum(torch.abs(h1[j])) #+ torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1))))
                    summ2 += torch.sum(torch.abs(h1[j] - h2[j]))
            
            print(summ / summ_ref, summ1 / summ1_ref, summ2 / summ2_ref, summ1_ref, summ2_ref)
            return float(summ / summ_ref), float(summ1 / summ1_ref), float(summ2 / summ2_ref)
        
        def total_error2(sde_truth, sde, i0):
            
            summ = 0
            summ_ref = 0
            
            for i in range(t_size):
                summ += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i]) - sde.f(ts[i], ys_truth[i])))
                summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i])))
                        
            summ1 = 0
            summ1_ref = 0
            for i in range(t_size):
                s1 = sde_truth.g(ts[i], ys_truth[i])
                s2 = sde.g(ts[i], ys_truth[i])
                #if i0 > 50:
                #    print(s1, s2)
                    #pdb.set_trace()
                    
                for j in range(ys.shape[1]):
                    summ1_ref += s1[j, 0, 0]**2 + s1[j, 1, 1]**2#torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1))))
                    summ1 +=abs( s1[j, 0, 0]**2 - s2[j, 0, 0]**2) + abs(s1[j, 1, 1]**2 - s2[j, 1, 1]**2)
                
            print(summ / summ_ref, summ1 / summ1_ref)
            return float(summ / summ_ref), float(summ1 / summ1_ref)
        
        def total_error(sde_truth, sde, i0):
            
            summ = 0
            summ_ref = 0
            
            for i in range(t_size):
                summ += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i]) - sde.f(ts[i], ys_truth[i])))
                summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i])))
                        
            summ1 = 0
            summ1_ref = 0
            for i in range(t_size):
                s1 = sde_truth.g(ts[i], ys_truth[i])
                s2 = sde.g(ts[i], ys_truth[i])
                #if i0 > 50:
                #    print(s1, s2)
                    #pdb.set_trace()
                    
                for j in range(ys.shape[1]):
                    summ1_ref += torch.sum(torch.abs(torch.matmul(s1[j], s1[j].transpose(0, 1))))
                    summ1 += torch.sum(torch.abs(torch.matmul(s2[j], s2[j].transpose(0, 1)) - torch.matmul(s1[j], s1[j].transpose(0, 1))))
                
            print(summ / summ_ref, summ1 / summ1_ref)
            return float(summ / summ_ref), float(summ1 / summ1_ref)
    
    
        
        for i0 in tqdm(range(epoch)):
            #print(i)
            ys = sdeint(sde, y0, ts).to(device)  
            loss =  w2_decoupled(ys, ys_truth)
        
            if i0 % 10 == 0:
                print(i0, loss.item(), sigma_para, sigma_para2, noise, noise_2, batch_size)
                f_error, s_error, h_error = total_error1(sde_truth, sde, i0)
                error_f.append(f_error)
                error_s.append(s_error)
                error_h.append(h_error)
                ttime = time.time()
                
            loss_list.append(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        
        error_f_list.append(error_f[-1])
        error_s_list.append(error_s[-1])
        error_h_list.append(error_h[-1])
        torch.save(sde.state_dict(), 'model' + 'none_' + noise_type + noise_2 + str(sigma_para2) + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' +'.pkl')
        predict_data = pd.DataFrame(data = [[float(ys[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
        predict_data.to_csv('01none_prior_predict2d1_cir_damped2cuda' + '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        #predict_data = pd.DataFrame(data = [[float(ys[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
        #predict_data.to_csv('predict2d2_cir_damped2cuda'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' +'.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = loss_list)
        loss_data.to_csv('01none_prior_loss2d_cir_damped2cuda'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = error_f)
        loss_data.to_csv('01none_prior_f_error_cir_damped2cuda'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = error_s)
        loss_data.to_csv('01none_prior_s_error_cir_damped2cuda.csv'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = error_h)
        loss_data.to_csv('01none_prior_h_error_cir_damped2cuda.csv'+ '_' + noise_type + '_' + str(sigma_para) + '_' + str(cor) + '_' + str(repeat) + '_' + '.csv', header=False, index = False)
    
    return error_f_list, error_s_list, error_h_list

f_error_list = [[0 for i in range(noise2_num)] for j in range(noise1_num)]
sigma_error_list = [[0 for i in range(noise2_num)] for j in range(noise1_num)]
h_error_list = [[0 for i in range(noise2_num)] for j in range(noise1_num)]

f_error_list_std = [[0 for i in range(noise2_num)] for j in range(noise1_num)]
sigma_error_list_std = [[0 for i in range(noise2_num)] for j in range(noise1_num)]
h_error_list_std = [[0 for i in range(noise2_num)] for j in range(noise1_num)]

for i in range(noise1_num):
    for j in range(noise2_num):
        
        noise1 = noise_type1#'langevin'
        noise2 = noise_type2#'langevin'
        f_error, s_error, h_error = sde_run(0.05, noise1_step*i+start_noise1, noise2_step*j+start_noise2, noise1, noise2)
        f_error_list[i][j], sigma_error_list[i][j], h_error_list[i][j] = sum(f_error)/len(f_error), sum(s_error)/len(s_error), sum(h_error) / len(h_error)
        f_error_list_std[i][j], sigma_error_list_std[i][j], h_error_list_std[i][j] = torch.sqrt(torch.var(torch.tensor(f_error))), torch.sqrt(torch.var(torch.tensor(s_error))), torch.sqrt(torch.var(torch.tensor(h_error)))
        loss_data = pd.DataFrame(data = f_error)
        loss_data.to_csv(str(noise1_step*i+start_noise1) + str(noise2_step*i+start_noise2) + noise1+ noise2 + 'noprior_f_error'+ '_'  + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = s_error)
        loss_data.to_csv(str(noise1_step*i+start_noise1) + str(noise2_step*i+start_noise2) + noise1+ noise2 + 'noprior_s_error'+ '_'  + '.csv', header=False, index = False)

        loss_data = pd.DataFrame(data = h_error)
        loss_data.to_csv(str(noise1_step*i+start_noise1) + str(noise2_step*i+start_noise2) + noise1+ noise2 + 'noprior_h_error'+ '_'  + '.csv', header=False, index = False)


loss_data = pd.DataFrame(data = f_error_list)
loss_data.to_csv('none'+ noise1+ noise2 + 'f_error'+ '_'  + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = sigma_error_list)
loss_data.to_csv('none' + noise1+ noise2 +'s_error'+ '_' + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = h_error_list)
loss_data.to_csv('none'+ noise1+ noise2 + 'h_error'+ '_'  + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = f_error_list_std)
loss_data.to_csv('none' + noise1+ noise2 +'f_error'+ 'std' + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = sigma_error_list_std)
loss_data.to_csv('none'+ noise1+ noise2 + 's_error'+ 'std'  + '.csv', header=False, index = False)

loss_data = pd.DataFrame(data = h_error_list_std)
loss_data.to_csv('none' + noise1+ noise2 +'h_error'+ 'std' + '.csv', header=False, index = False)
