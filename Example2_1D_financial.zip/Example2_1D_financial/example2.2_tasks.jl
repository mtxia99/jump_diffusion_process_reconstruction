using Distributed
addprocs(5)
@everywhere using ProgressMeter

σ1s = [0.025 + 0.025 * i for i in 0:4]
σ2s = [0.025 + 0.025 * i for i in 0:4]
noise_types = ["linear", "const", "langevin"]
params = [(σ1, σ2, noise_type) for σ1 in σ1s for σ2 in σ2s for noise_type in noise_types]

@everywhere function run_with_logging(σ1, σ2, noise_type)
    cmd =  `python example2_base_fprior.py --noise_type1=$(noise_type) --noise_type2=$(noise_type) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=10`
    run(pipeline(`$(cmd)`, stdout="log/$(σ1)_$(σ2)_$(noise_type).log", stderr="log/$(σ1)_$(σ2)_$(noise_type).log"))
end


progress_pmap( x -> run_with_logging(x[1], x[2],x[3]), params;
progress=Progress(length(params), showspeed=true))