using CSV, DataFrames, PGFPlotsX
################# W2 decoupled #################
# path to ground truth
gt = CSV.read("data/example2_fprior_ground_truth_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# each column is a time point,
# each row is a sample
ts = 0:0.1:5 |> collect
tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "time \$ t \$",
        ylabel = "\$X(t)\$",
        width = "2.4in",
        height = "2.4in",
        # ymin=2,
        # ymax=9.9,
        "after end axis/.code" = {
            "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.02,0.98) {(a)};"
        },
    }
)

for j in 1:40
xs = [gt[j,i] for i in 1:size(gt,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "black!50!white",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else 
push!(axis, @pgf PlotInc(
    {
        color = "black",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
axis

# path to prediction
pred = CSV.read("data/example2_fprior_predict_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# same format
for j in 1:40
xs = [pred[j,i] for i in 1:size(pred,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
# add legend 
push!(axis, @pgf LegendEntry("ground truth"))
push!(axis, @pgf LegendEntry("drift prior"))
axis
push!(tikzpicture, axis)
pgfsave("example2_plot_a.tex", tikzpicture)
pgfsave("example2_plot_a.pgf", tikzpicture)


################# sigma prior #################
gt = CSV.read("data/example2_sigmaprior_ground_truth_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# each column is a time point,
# each row is a sample
ts = 0:0.1:5 |> collect
tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "time \$ t \$",
        ylabel = "\$X(t)\$",
        width = "2.4in",
        height = "2.4in",
        # ymin=2,
        # ymax=9.9,
        "after end axis/.code" = {
            "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.02,0.98)  {(b)};"
        },
    }
)

for j in 1:40
xs = [gt[j,i] for i in 1:size(gt,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "black!50!white",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else 
push!(axis, @pgf PlotInc(
    {
        color = "black",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
axis

# path to prediction
pred = CSV.read("data/example2_sigmaprior_predict_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# same format
for j in 1:40
xs = [pred[j,i] for i in 1:size(pred,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
# add legend 
push!(axis, @pgf LegendEntry("ground truth"))
push!(axis, @pgf LegendEntry("diffusion prior"))
axis
push!(tikzpicture, axis)
pgfsave("example2_plot_b.tex", tikzpicture)   
pgfsave("example2_plot_b.pgf", tikzpicture)

################# h prior #################
gt = CSV.read("data/example2_hprior_ground_truth_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# each column is a time point,
# each row is a sample
ts = 0:0.1:5 |> collect
tikzpicture = @pgf TikzPicture({baseline})
axis = @pgf Axis(
    {
        xlabel = "time \$ t \$",
        ylabel = "\$X(t)\$",
        width = "2.4in",
        height = "2.4in",
        # ymin=2,
        # ymax=9.9,
        "after end axis/.code" = {
            "\\node[anchor=north west, font=\\fontsize{12}{14}\\selectfont, fill=white] at (rel axis cs:0.02,0.98) {(c)};"
        },
    }
)

for j in 1:40
xs = [gt[j,i] for i in 1:size(gt,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "black!50!white",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else
push!(axis, @pgf PlotInc(
    {
        color = "black",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
axis

# path to prediction
pred = CSV.read("data/example2_hprior_predict_langevin_langevin0.1_0_0.csv", DataFrame; header=false)
# same format
for j in 1:40
xs = [pred[j,i] for i in 1:size(pred,2)]
if j ≠ 1
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
        forget_plot = true,
    },
    Table(ts, xs)
))
else
push!(axis, @pgf PlotInc(
    {
        color = "red",
        mark = "none",
    },
    Table(ts, xs)
))
end
end
# add legend
push!(axis, @pgf LegendEntry("ground truth"))
push!(axis, @pgf LegendEntry("jump prior"))
axis
push!(tikzpicture, axis)
pgfsave("example2_plot_c.tex", tikzpicture)
pgfsave("example2_plot_c.pgf", tikzpicture)