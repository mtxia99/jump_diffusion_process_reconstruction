using Distributed
# addprocs(2)
addprocs([("asrock",2),("rackmount",2),("rog-ld03",2)])
@everywhere using ProgressMeter

σ1 = 0.1
σ2 = 0.1
sample_sizes = [100,200,400,800]
noise_type1s = ["langevin"]
noise_type2s = ["langevin"]
prior_types = ["fprior","sigmaprior","hprior"]
params = [(σ1, σ2, prior_type, noise_type1, noise_type2, sample_size) for prior_type in prior_types for noise_type1 in noise_type1s for noise_type2 in noise_type2s for sample_size in sample_sizes]
@everywhere function run_with_logging(σ1, σ2, prior_type, noise_type1, noise_type2, sample_size)
    cmd = `python example2_ext.py --prior=$(prior_type) --noise_type1=$(noise_type1) --noise_type2=$(noise_type2) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=5 --sample_size=$(sample_size)`
    @show cmd
    run(pipeline(`$(cmd)`, stdout="log/$(prior_type)_$(σ1)_$(σ2)_$(noise_type1)_$(noise_type2)_$(sample_size).log", stderr="log/$(prior_type)_$(σ1)_$(σ2)_$(noise_type1)_$(noise_type2)_$(sample_size).err"))
end


progress_pmap( x -> run_with_logging(x[1], x[2],x[3], x[4],x[5], x[6]), params;
progress=Progress(length(params), showspeed=true))
