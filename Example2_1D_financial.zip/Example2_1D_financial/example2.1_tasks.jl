using Distributed
addprocs(2)
@everywhere using ProgressMeter

σ1 = 0.1
σ2 = 0.1
noise_type1s = ["linear", "const", "langevin"]
noise_type2s = ["linear", "const", "langevin"]
prior_types = ["noprior", "fprior", "sigmaprior", "hprior"]
params = [(σ1, σ2, prior_type, noise_type1, noise_type2) for prior_type in prior_types for noise_type1 in noise_type1s for noise_type2 in noise_type2s]
@everywhere function run_with_logging(σ1, σ2, prior_type, noise_type1, noise_type2)
    if prior_type == "noprior"
        cmd = `python example2_base.py --noise_type1=$(noise_type1) --noise_type2=$(noise_type2) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=5`
    elseif prior_type == "fprior"
        cmd = `python example2_base_fprior.py --noise_type1=$(noise_type1) --noise_type2=$(noise_type2) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=5`
    elseif prior_type == "sigmaprior"
        cmd = `python example2_base_sigmaprior.py --noise_type1=$(noise_type1) --noise_type2=$(noise_type2) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=5`
    elseif prior_type == "hprior"
        cmd = `python example2_base_hprior.py --noise_type1=$(noise_type1) --noise_type2=$(noise_type2) --noise_strength1=$(σ1) --noise_strength2=$(σ2) --repeat=5`
    else
        
        error("Unknown prior type: $(prior_type)")
    end
    run(pipeline(`$(cmd)`, stdout="log/$(prior_type)_$(σ1)_$(σ2)_$(noise_type1)_$(noise_type2).log", stderr="log/$(prior_type)_$(σ1)_$(σ2)_$(noise_type1)_$(noise_type2).err"))
end


progress_pmap( x -> run_with_logging(x[1], x[2],x[3], x[4],x[5]), params;
progress=Progress(length(params), showspeed=true))
